import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 *
 * @author gal.
 *
 */
public class Game {
   private SpriteCollection sprites;
   private GameEnvironment environment;
   private GUI gui;
   /**
    *
    */
   public Game() {
       this.environment = new GameEnvironment();
       this.sprites = new SpriteCollection();
       this.gui = new GUI("Arkanoid", 1300, 600);
   }
   /**
    *
    * @param c a Collidable
    */
   public void addCollidable(Collidable c) {
       this.environment.addCollidable(c);
   }
   /**
    *
    * @param s a Sprite
    */
   public void addSprite(Sprite s) {
       this.sprites.addSprite(s);
   }
   // Initialize a new game: create the Blocks and Ball (and Paddle)
   // and add them to the game.
   /**
    *
    */
   public void initialize() {
       Paddle p = new Paddle(new Rectangle(300, 550, 250, 20), this.gui.getKeyboardSensor());
       p.getCollisionRectangle().setColor(java.awt.Color.BLUE);
       p.addToGame(this);
       Ball ball = new Ball(500, 500, 8, java.awt.Color.YELLOW);
       ball.setGameEnvironment(this.environment);
       ball.addToGame(this);
       frameInitialize();
       blocksInitialize();
   }
   /**
    *
    */
   public void frameInitialize() {
       Block block = new Block(new Rectangle(0, 0, 30, 600));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block = new Block(new Rectangle(30, 570, 1270, 30));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block = new Block(new Rectangle(1270, 0, 30, 600));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block = new Block(new Rectangle(30, 0, 1240, 30));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
   }
   /**
    *
    */
   public void blocksInitialize() {
       blocksInitialize1();
       blocksInitialize2();
       blocksInitialize3();
       blocksInitialize4();
       blocksInitialize5();
       blocksInitialize6();
   }
   /**
   *
   */
   public void blocksInitialize1() {
       int count = 80;
       Block block = null;
       for (int i = 0; i < 12; i++) {
           block = new Block(new Rectangle(1270 - ((i + 1) * count), 150, 80, 30));
           block.getCollisionRectangle().setColor(java.awt.Color.PINK);
           block.setHit(2);
           block.addToGame(this);
       }
   }
   /**
   *
   */
   public void blocksInitialize2() {
       int count = 80;
       Block block = null;
       for (int i = 0; i < 11; i++) {
           block = new Block(new Rectangle(1270 - ((i + 1) * count), 180, 80, 30));
           block.getCollisionRectangle().setColor(java.awt.Color.BLUE);
           block.setHit(1);
           block.addToGame(this);
       }
   }
   /**
   *
   */
   public void blocksInitialize3() {
       int count = 80;
       Block block = null;
       for (int i = 0; i < 10; i++) {
           block = new Block(new Rectangle(1270 - ((i + 1) * count), 210, 80, 30));
           block.getCollisionRectangle().setColor(java.awt.Color.RED);
           block.setHit(1);
           block.addToGame(this);
       }
   }
   /**
   *
   */
   public void blocksInitialize4() {
       int count = 80;
       Block block = null;
       for (int i = 0; i < 9; i++) {
           block = new Block(new Rectangle(1270 - ((i + 1) * count), 240, 80, 30));
           block.getCollisionRectangle().setColor(java.awt.Color.GREEN);
           block.setHit(1);
           block.addToGame(this);
       }
   }
   /**
   *
   */
   public void blocksInitialize5() {
       int count = 80;
       Block block = null;
       for (int i = 0; i < 8; i++) {
           block = new Block(new Rectangle(1270 - ((i + 1) * count), 270, 80, 30));
           block.getCollisionRectangle().setColor(java.awt.Color.YELLOW);
           block.setHit(1);
           block.addToGame(this);
       }
   }
   /**
   *
   */
   public void blocksInitialize6() {
       int count = 80;
       Block block = null;
       for (int i = 0; i < 7; i++) {
           block = new Block(new Rectangle(1270 - ((i + 1) * count), 300, 80, 30));
           block.getCollisionRectangle().setColor(java.awt.Color.ORANGE);
           block.setHit(1);
           block.addToGame(this);
       }
   }
   // Run the game -- start the animation loop.
   /**
    *
    */
   public void run() {
       int framesPerSecond = 60;
       int millisecondsPerFrame = 1000 / framesPerSecond;
       Sleeper sleeper = new Sleeper();
       while (true) {
          long startTime = System.currentTimeMillis(); // timing
          DrawSurface d = gui.getDrawSurface();
          this.sprites.drawAllOn(d);
          gui.show(d);
          this.sprites.notifyAllTimePassed();
          // timing
          long usedTime = System.currentTimeMillis() - startTime;
          long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
          if (milliSecondLeftToSleep > 0) {
              sleeper.sleepFor(milliSecondLeftToSleep);
          }
       }
   }
}