import biuoop.DrawSurface;

/**
 *
 * @author gal.
 *
 */
public class Block  implements Collidable, Sprite {
    private Rectangle rect;
    private String hit1;
    /**
     *
     * @param rect a Rectangle
     */
    public Block(Rectangle rect) {
        this.rect = rect;
        this.hit1 = "X";
    }
    /**
     *
     */
    public void timePassed() {
    }
    /**
     * @return a Rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }
    /**
     * @param surface a DrawSurface
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.getCollisionRectangle().getColor());
        surface.fillRectangle((int) this.rect.getUpperLeft().getX(), (int) this.rect.getUpperLeft().getY(),
                (int) this.rect.getWidth(), (int) this.rect.getHeight());
        surface.setColor(java.awt.Color.BLACK);
        surface.drawRectangle((int) this.rect.getUpperLeft().getX(), (int) this.rect.getUpperLeft().getY(),
                (int) this.rect.getWidth(), (int) this.rect.getHeight());
        surface.drawText((int) (this.rect.getUpperLeft().getX() + this.getCollisionRectangle().getWidth() / 2),
                (int) (this.rect.getUpperLeft().getY() + this.getCollisionRectangle().getHeight() / 2),
                hit1,  25);

    }
    /**
     *
     * @param g a Game
     */
    public void addToGame(Game g) {
        g.addSprite(this);
        g.addCollidable(this);
    }
    /**
     *
     * @param x a int
     */
    public void setHit(int x) {
        this.hit1 = Integer.toString(x);
    }
    /**
     *
     */
    public void setHitS() {
        this.hit1 = "X";
    }
    /**
     *
     * @return the hit1
     */
    public String getHit() {
       return this.hit1;
    }
    /**
    *
    * @param collisionPoint a Point
    * @param currentVelocity a Velocity
    * @return a new velocity after the hit
    */
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        if (this.hit1 != "X") {
            if ((Integer.parseInt(this.hit1)) > 1) {
                setHit(Integer.parseInt(this.hit1) - 1);
            } else {
                setHitS();
            }
        }
        Velocity newVelocity = null;
        if (this.rect.getDown().inLine(collisionPoint) || this.rect.getUp().inLine(collisionPoint)) {
            newVelocity = new Velocity(currentVelocity.getX(), -currentVelocity.getY());
        }
        if (this.rect.getRight().inLine(collisionPoint) || this.rect.getLeft().inLine(collisionPoint)) {
            newVelocity = new Velocity(-currentVelocity.getX(), currentVelocity.getY());
        }
        return newVelocity;
    }
}
