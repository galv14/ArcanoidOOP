import java.util.List;
/**
 *
 * @author gal eini
 * 305216962
 *
 */

public class Line {
    private Point start;
    private Point end;
    private Point middle;
 // constructors
    /**
     *
     * @param start a point
     * @param end a point
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
        double midX = (start.getX() + end.getX()) / 2;
        double midY = (start.getY() + end.getY()) / 2;
        this.middle = new Point(midX, midY);
    }
    /**
     *
     * @param x1 x value
     * @param y1 y value
     * @param x2 x value
     * @param y2 y value
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
        double midX = (x1 + x2) / 2;
        double midY = (y1 + y2) / 2;
        this.middle = new Point(midX, midY);
    }

    // Return the length of the line
    /**
     *
     * @return the length of the liine
     */
    public double length() {
        return this.start.distance(end);
    }

    // Returns the middle point of the line
    /**
     *
     * @return the middle point of the line
     */
    public Point middle() {
        return this.middle;
    }

    // Returns the start point of the line
    /**
     *
     * @return the start point of the line
     */
    public Point start() {
        return this.start;
    }

    // Returns the end point of the line
    /**
     *
     * @return the end point of the line
     */
    public Point end() {
        return this.end;
    }
    /**
     *
     * @return the slope of the line
     */
    public double getSlope() {
        double thisSlope;
        double m = Double.POSITIVE_INFINITY;
       if (this.start.getX() - this.end.getX() != 0) {
            thisSlope = (this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX());
            return thisSlope;
        }
       return m;
    }
    /**
     *
     * @param p a Point
     * @return true if the point is in the line, false otherwise
     */
    public boolean inLine(Point p) {
        double equation;
        double thisSlope;
        thisSlope = getSlope();
        if (thisSlope != Double.POSITIVE_INFINITY) {
            equation = -thisSlope * this.start.getX() + this.start.getY();
            if (Math.abs(thisSlope * p.getX() - p.getY() + equation) < 2) {
              if ((p.getX() >= this.start.getX() && p.getX() <= this.end.getX())
                  || (p.getX() <= this.start.getX() && p.getX() >= this.end.getX())) {
                  if ((p.getY() >= this.start.getY() && p.getY() <= this.end.getY())
                          || (p.getY() <= this.start.getY() && p.getY() >= this.end.getY())) {
                      return true;
                  }
              }
          }
        } else if (p.getX() == this.start.getX()) {
            if ((p.getY() >= this.start.getY() && p.getY() <= this.end.getY())
                    || (p.getY() <= this.start.getY() && p.getY() >= this.end.getY())) {
                return true;
            }
        }
      return false;
    }
    /**
     *
     * @param rect a rectangle
     * @return the closet intersection point with the rectangle
     *  to the start of the line
     */
    public Point closrtOfLine(Rectangle rect) {
        Point closet = null;
        if (this.isIntersecting(rect.getUp())) {
           closet = this.intersectionWith(rect.getUp());
        }
        if (this.isIntersecting(rect.getDown())) {
            if (closet == null) {
                closet = this.intersectionWith(rect.getDown());
            } else if (Math.abs(this.intersectionWith(rect.getDown()).distance(this.start))
                    <= Math.abs(closet.distance(this.start))) {
            closet = this.intersectionWith(rect.getDown());
            }
        }
        if (this.isIntersecting(rect.getRight())) {
            if (closet == null) {
                closet = this.intersectionWith(rect.getRight());
            } else if (Math.abs(this.intersectionWith(rect.getRight()).distance(this.start))
                    <= Math.abs(closet.distance(this.start))) {
            closet = this.intersectionWith(rect.getRight());
            }
        }
        if (this.isIntersecting(rect.getLeft())) {
            if (closet == null) {
                closet = this.intersectionWith(rect.getLeft());
            } else if (Math.abs(this.intersectionWith(rect.getLeft()).distance(this.start))
                    <= Math.abs(closet.distance(this.start))) {
            closet = this.intersectionWith(rect.getLeft());
            }
        }
        return closet;
    }
    /**
    *
    * @param rect a rectangle
    * @return the closet intersection point with the rectangle
    *  to the start of the line
    */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        List<Point> l = null;
        l = rect.intersectionPoints(this);
        Point closest = null;
        if (l.size() > 0) {
            closest = l.get(0);
            for (int i = 1; i < l.size(); i++) {
                if (closest.distance(this.start()) >= l.get(i).distance(this.start())) {
                    closest = l.get(i);
                }
            }
        }
        return closest;
    }
    // Returns true if the lines intersect, false otherwise
    /**
     *
     * @param other a line
     * @return true if the lines intersect, false otherwise
     */
    public boolean isIntersecting(Line other) {
        if (intersectionWith(other) != null) {
            return true;
        }
        return false;
    }

    // Returns the intersection point if the lines intersect,
    // and null otherwise.
    /**
     *
     * @param other a line
     * @return other Returns the intersection point if the lines intersect,
     * and null otherwise.
     */
    public Point intersectionWith(Line other) {
        double thisSlope;
        double otherSlope;
        double equationA;
        double equationB;
        double itrX;
        double itrY;
        Point intersact;
        thisSlope = this.getSlope();
        otherSlope = other.getSlope();
        if (thisSlope != otherSlope) {
            if (thisSlope == Double.POSITIVE_INFINITY) {
                equationA = this.start.getX();
                equationB = otherSlope * other.start.getX() - other.start.getY();
                itrY = (otherSlope * equationA) - equationB;
                intersact = new Point(equationA, itrY);
            } else if (otherSlope == Double.POSITIVE_INFINITY) {
                equationA = thisSlope * this.start.getX() - this.start.getY();
                equationB = other.start.getX();
                itrY = (thisSlope * equationB) - equationA;
                intersact = new Point(equationB, itrY);
            } else {
                equationA = thisSlope * this.start.getX() - this.start.getY();
                equationB = otherSlope * other.start.getX() - other.start.getY();
                itrX = (equationA - equationB) / (thisSlope - otherSlope);
                itrY = (thisSlope * itrX) - equationA;
                intersact = new Point(itrX, itrY);
            }
            if (this.inLine(intersact) && (other.inLine(intersact))) {
                            return intersact;
                        }
           return null;
        }
        if ((this.end.equals(other.start)) || (this.start.equals(other.start))) {
            if ((other.end.getX() >= this.end.getX() && other.end.getX() <= this.start.getX())
                    || (other.end.getX() <= this.end.getX() && other.end.getX() <= this.start.getX())) {
                if ((other.end.getY() >= this.end.getY() && other.end.getY() <= this.start.getY())
                        || (other.end.getY() <= this.end.getY() && other.end.getY() <= this.start.getY())) {
                    return null;
                }
            }
            return this.end;
        }
        if ((this.start.equals(other.end)) || (this.end.equals(other.end))) {
            if ((other.start.getX() >= this.end.getX() && other.start.getX() <= this.start.getX())
                    || (other.start.getX() <= this.end.getX() && other.start.getX() <= this.start.getX())) {
                if ((other.start.getY() >= this.end.getY() && other.start.getY() <= this.start.getY())
                        || (other.start.getY() <= this.end.getY() && other.start.getY() <= this.start.getY())) {
                    return null;
                }
            }
            return this.start;
        }
        return null;
    }

    // equals -- return true is the lines are equal, false otherwise
    /**
     *
     * @param other a line
     * @return true is the lines are equal, false otherwise
     */
    public boolean equals(Line other) {
        if (this.start.equals(other.start) && this.end.equals(other.end)) {
            return true;
        }
        if (this.start.equals(other.end) && this.end.equals(other.start)) {
            return true;
        }
        return false;
    }
}
