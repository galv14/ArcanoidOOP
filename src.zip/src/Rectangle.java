import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author gal.
 *
 */
class Rectangle {
    private Point upperLeft;
    private double width;
    private double height;
    private Line up;
    private Line left;
    private Line down;
    private Line right;
    private java.awt.Color color;

   // Create a new rectangle with location and width/height.
    /**
     *
     * @param upperLeft a Point
     * @param width a double
     * @param height a double
     */
   public Rectangle(Point upperLeft, double width, double height) {
       this.upperLeft = upperLeft;
       this.width = width;
       this.height = height;
       this.up = new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX() + width, upperLeft.getY());
       this.left = new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX(), upperLeft.getY() + height);
       this.down = new Line(upperLeft.getX(), upperLeft.getY() + height,
               upperLeft.getX() + width, upperLeft.getY() + height);
       this.right = new Line(upperLeft.getX() + width, upperLeft.getY(),
               upperLeft.getX() + width, upperLeft.getY() + height);
   }
   /**
   *
   * @param x the x value
   * @param y the x value
   * @param width a double
   * @param height a double
   */
   public Rectangle(double x, double y, double width, double height) {
       this.upperLeft = new Point(x, y);
       this.width = width;
       this.height = height;
       this.up = new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX() + width, upperLeft.getY());
       this.left = new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX(), upperLeft.getY() + height);
       this.down = new Line(upperLeft.getX(), upperLeft.getY() + height,
               upperLeft.getX() + width, upperLeft.getY() + height);
       this.right = new Line(upperLeft.getX() + width, upperLeft.getY(),
               upperLeft.getX() + width, upperLeft.getY() + height);
   }
   // Return a (possibly empty) List of intersection points
   // with the specified line.
   /**
    *
    * @param line a Line
    * @return a List with the intersection points of the line with the rectangle
    */
   public java.util.List<Point> intersectionPoints(Line line) {
       List<Point> l = new ArrayList<Point>();
      // System.out.println(this.up.start().getX());
       //System.out.println(this.getUpperLeft());
       if (this.up.isIntersecting(line)) {
           l.add(this.up.intersectionWith(line));
           //System.out.println(this.up.intersectionWith(line));
       }
       if (this.down.isIntersecting(line)) {
           l.add(this.down.intersectionWith(line));
          // System.out.println(this.down.intersectionWith(line));
       }
       if (this.left.isIntersecting(line)) {
           l.add(this.left.intersectionWith(line));
           //System.out.println(this.left.intersectionWith(line));
       }
       if (this.right.isIntersecting(line)) {
           l.add(this.right.intersectionWith(line));
           //System.out.println(this.right.intersectionWith(line));
       }
       return l;

   }
   // Return the width and height of the rectangle
   /**
    *
    * @return the width
    */
   public double getWidth() {
       return this.width;
   }
   /**
    *
    * @return the height
    */
   public double getHeight() {
       return this.height;
   }
   // Returns the upper-left point of the rectangle.
   /**
    *
    * @return the upper left Point
    */
   public Point getUpperLeft() {
       return this.upperLeft;
   }
   /**
    *
    * @param p a Point
    */
   public void setUpperLeft(Point p) {
       this.upperLeft = p;
       this.up = new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX() + width, upperLeft.getY());
       this.left = new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX(), upperLeft.getY() + height);
       this.down = new Line(upperLeft.getX(), upperLeft.getY() + height,
               upperLeft.getX() + width, upperLeft.getY() + height);
       this.right = new Line(upperLeft.getX() + width, upperLeft.getY(),
               upperLeft.getX() + width, upperLeft.getY() + height);
   }
    /**
    *
    * @return the top rectangle line
    */
   public Line getUp() {
       return this.up;
   }
   /**
    *
    * @return the bottom rectangle line
    */
   public Line getDown() {
       return this.down;
   }
   /**
    *
    * @return the left rectangle line
    */
   public Line getLeft() {
       return this.left;
   }
   /**
    *
    * @return the right rectangle line
    */
   public Line getRight() {
       return this.right;
   }
   /**
    *
    * @return the color of the rectangle
    */
   public java.awt.Color getColor() {
       return this.color;
   }
   /**
    *
    * @param color1 a java.awt.Color
    */
   public void setColor(java.awt.Color color1) {
       this.color = color1;
   }
}