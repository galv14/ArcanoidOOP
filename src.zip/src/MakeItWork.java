/**
 *
 * @author gal.
 *
 */
public class MakeItWork {
    /**
     *
     * @param args user
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
     }
}
