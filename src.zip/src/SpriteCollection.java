import java.util.ArrayList;
import java.util.List;
import biuoop.DrawSurface;
/**
 *
 * @author gal.
 *
 */
public class SpriteCollection {
    private List<Sprite> l;
    /**
     *
     */
    public SpriteCollection() {
        this.l = new ArrayList<Sprite>();
    }
    /**
     *
     * @param s a Sprite
     */
   public void addSprite(Sprite s) {
       this.l.add(s);
   }
   // call timePassed() on all sprites.
   /**
    *
    */
   public void notifyAllTimePassed() {
       for (int i = 0; i < l.size(); i++) {
           l.get(i).timePassed();
       }
   }
   // call drawOn(d) on all sprites.
   /**
    *
    * @param d a DrawSurface
    */
   public void drawAllOn(DrawSurface d) {
       for (int i = 0; i < l.size(); i++) {
           l.get(i).drawOn(d);;
       }
   }
}