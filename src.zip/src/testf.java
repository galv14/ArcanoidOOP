import java.util.List;

/**
 *
 * @author gal
 *
 */
public class testf {
    /**
     *
     * @param args user
     */
    public static void main(String[] args) {
        Rectangle x1 = new Rectangle(50, 120, 20, 10);
      //  Block b1 = new Block(new Rectangle(50, 120, 40, 40));
      //  b1.getCollisionRectangle().setColor(java.awt.Color.PINK);
        Line l = new Line(10, 20, 40, 15);
        Line r = new Line(25, 30, 25, 3);
       // Point p = new Point(50, 130);
        List<Point> fg = null;
      //  if (x1.getLeft().inLine(p)) {
            //System.out.println("true in line");
     //   } else { //System.out.println("false in line");
      //  }
       // if (l.closestIntersectionToStartOfLine(x1) != null) {
           // System.out.println("true closestIntersectionToStartOfLine");
       // } else { //System.out.println("false closestIntersectionToStartOfLine");
       // }
        if (r.isIntersecting(l)) {
            System.out.println("true isIntersecting thisinf");
        } else { System.out.println("false isIntersecting thisinf");
        }
        if (l.isIntersecting(r)) {
            System.out.println("true isIntersecting otherinf");
        } else { System.out.println("false isIntersecting otherinf");
        }
        fg = x1.intersectionPoints(l);
        if (fg.size() > 0) {
            System.out.println(fg.size());
        }
       // GUI gui = new GUI("title", 1000, 1000);
        //DrawSurface d = gui.getDrawSurface();
        //d.drawLine(2,1,20,46);
        //d.drawLine(50,120,50,130);
        //b1.getCollisionRectangle().drawOn(d);
       // gui.show(d);
    }

}
