import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gal.
 *
 */
public class GameEnvironment {
    private List<Collidable> l;
    /**
     *
     */
    public GameEnvironment() {
        this.l = new ArrayList<Collidable>();
    }
   // add the given collidable to the environment.
    /**
     *
     * @param c a Collidable
     */
   public void addCollidable(Collidable c) {
       this.l.add(c);
   }
   /**
    *
    * @param i a int
    * @return the Collidable in the list in the index
    */
   public Collidable getCollidable(int i) {
       return this.l.get(i);
   }

   // Assume an object moving from line.start() to line.end().
   // If this object will not collide with any of the collidables
   // in this collection, return null. Else, return the information
   // about the closest collision that is going to occur.
   /**
    *
    * @param trajectory a line
    * @return null if this object will not collide with any of the collidables
    * in this collection. Else, return the information
    * about the closest collision that is going to occur.
    */
   public CollisionInfo getClosestCollision(Line trajectory) {
       Point temp = null;
       Point point = trajectory.closestIntersectionToStartOfLine(this.l.get(0).getCollisionRectangle());;
       int size = this.l.size();
       int i = 0;
       int shapeIndex = 0;
       CollisionInfo x = null;
       for (i = 1; i < size; i++) {
               if (point == null) {
                   point = trajectory.closestIntersectionToStartOfLine(this.l.get(i).getCollisionRectangle());
                   if (point != null) {
                       shapeIndex = i;
                   }
               } else {
                   temp = trajectory.closestIntersectionToStartOfLine(this.l.get(i).getCollisionRectangle());
               }
                if (point != null && temp != null) {
                   if (point.distance(trajectory.start()) > temp.distance(trajectory.start())) {
                       point = temp;
                       shapeIndex = i;
                   }
              }
           }
       if (point != null) {
           x = new CollisionInfo(point, this.l.get(shapeIndex));
       }
       return x;
   }
}
