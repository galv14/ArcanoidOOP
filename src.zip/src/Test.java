import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
/**
 *
 * @author gal.
 *
 */
public class Test {
    /**
     *
     * @param args user
     */
    public static void main(String[] args) {
        Ball ball = new Ball(200, 150, 10, java.awt.Color.PINK);
        //Rectangle x1 = new Rectangle(50, 120, 20, 10);
       // Rectangle x2 = new Rectangle(150, 120, 20, 10);
       // Rectangle x3 = new Rectangle(250, 220, 20, 10);
       // Rectangle x4 = new Rectangle(350, 420, 20, 10);
        Block b1 = new Block(new Rectangle(0, 0, 1000, 50));
        Block b2 = new Block(new Rectangle(0, 0, 50, 1000));
        Block b3 = new Block(new Rectangle(0, 500, 1000, 50));
        Block b4 = new Block(new Rectangle(400, 00, 50, 1000));
        b1.getCollisionRectangle().setColor(java.awt.Color.PINK);
        b2.getCollisionRectangle().setColor(java.awt.Color.PINK);
        b3.getCollisionRectangle().setColor(java.awt.Color.PINK);
        b4.getCollisionRectangle().setColor(java.awt.Color.PINK);
        GameEnvironment game = new GameEnvironment();
        game.addCollidable(b1);
        game.addCollidable(b2);
        game.addCollidable(b3);
        game.addCollidable(b4);
        GUI gui = new GUI("title", 1000, 1000);
        Sleeper sleeper = new Sleeper();
        Velocity v = Velocity.fromAngleAndSpeed(70, 250);
        ball.setVelocity(v);
        ball.setGameEnvironment(game);
        //DrawSurface d = gui.getDrawSurface();
        ball.setTrajectory(ball.getCenter(), ball.getVelocity().applyToPoint(ball.getCenter()));
        while (true) {

            ball.timePassed();
            DrawSurface d = gui.getDrawSurface();
            b1.drawOn(d);
            b2.drawOn(d);
            b3.drawOn(d);
            b4.drawOn(d);
            ball.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(100);  // wait for 50 milliseconds.
         }
    }
}
