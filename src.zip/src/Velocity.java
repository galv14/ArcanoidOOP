/**
 *
 * @author gal eini
 * 305216962
 *
 */
//Velocity specifies the change in position on the `x` and the `y` axes.
public class Velocity {
    private double x;
    private double y;
    // constructor
    /**
     *
     * @param dx the x value of the circle
     * @param dy the y value of the circle
     */
    public Velocity(double dx, double dy) {
        this.x = dx;
        this.y = dy;
    }
    /**
     *
     * @return the x value of the velocity
     */
    public double getX() {
        return this.x;
    }
    /**
     *
     * @return the x value of the velocity
     */
    public double getY() {
        return this.y;
    }
    /**
     *
     * @param angle the degrees of the angle
     * @param speed the speed of the movement
     * @return the velocity in x and y
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double dx = speed * Math.cos(3.14 * (angle - 90) / 180);
        double dy = speed * Math.sin(3.14 * (angle - 90) / 180);
        return new Velocity(dx, dy);
     }
    /**
     *
     * @return the angle
     */
    public double getAngle() {
        double angle = Math.atan(this.y / this.x);
        return angle;
    }
    /**
     *
     * @return the speed
     */
    public double getSpeed() {
        double speed = Math.sqrt(this.x * this.x + this.y * this.y);
        return speed;
    }
    // Take a point with position (x,y) and return a new point
    // with position (x+dx, y+dy)
    /**
     *
     * @param p a point with position (x,y)
     * @return a new point with position (x+dx, y+dy)
     */
    public Point applyToPoint(Point p) {
        double newX = p.getX() + this.x;
        double newY = p.getY() + this.y;
        Point newPoint = new Point(newX, newY);
        return newPoint;
    }
}
