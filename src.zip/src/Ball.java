import biuoop.DrawSurface;
/**
*
* @author gal eini
* 305216962
*
*/
public class Ball implements Sprite {
    private Point center;
    private int r;
    private java.awt.Color color;
    private Velocity velocity;
    private GameEnvironment game1;
    private Line trajectory;
    // constructor
    /**
     *
     * @param center value of the center
     * @param r value of the radius
     * @param color the color of the circle
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.velocity = new Velocity(0, 0);
    }
    /**
     *
     * @param x the x value of the center
     * @param y the y value of the center
     * @param r the value of the radius
     * @param color the color of the circle
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        this.r = r;
        this.color = color;
        this.velocity = new Velocity(0, 0);
        }
    // accessors
    /**
     *
     * @return the x value of the center
     */
    public int getX() {
        return (int) this.center.getX();
    }
    /**
     *
     * @return the y value of the center
     */
    public int getY() {
        return (int) this.center.getY();
    }
    /**
     *
     * @return the value of the radius
     */
    public int getSize() {
        return this.r;
    }
    /**
     *
     * @return the color of the circle
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    // draw the ball on the given DrawSurface
    /**
     *
     * @param surface the DrawSurface which will be drawn on
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.getColor());
        surface.fillCircle(this.getX(), this.getY(), this.r);
    }
    /**
     *
     * @param v the velocity of the ball
     */
    public void setVelocity(Velocity v) {
        this.velocity = v;
    }
    /**
     *
     * @param game2 a GameEnvironment
     */
    public void setGameEnvironment(GameEnvironment game2) {
        this.game1 = game2;
    }
    /**
     *
     * @param dx the x value of the velocity of the ball
     * @param dy the y value of the velocity of the ball
     */
    public void setVelocity(double dx, double dy) {
        this.velocity = new  Velocity(dx, dy);
    }
    /**
     *
     * @return the velocity of the ball
     */
    public Velocity getVelocity() {
        return this.velocity;
    }
    /**
     *
     * @return the center of the line
     */
    public Point getCenter() {
        return this.center;
    }
    /**
     *
     * @param a Point
     * @param b Point
     */
    public void setTrajectory(Point a, Point b) {
        this.trajectory = new Line(a, b);
    }
    /**
     *
     * @param g a Game
     */
    public void addToGame(Game g) {
        Velocity v = Velocity.fromAngleAndSpeed(160, 5);
        this.setVelocity(v);
        g.addSprite(this);
    }
    /**
     *
     */
    public void timePassed() {
        this.trajectory = new Line(getCenter(), this.velocity.applyToPoint(this.center));
        CollisionInfo info = null;
        info = this.game1.getClosestCollision(this.trajectory);
        if (info == null) {
            this.center = trajectory.end();
        } else {
            if (trajectory.end().getX() - trajectory.start().getX() > 0) {
                this.center.setX(info.collisionPoint().getX() - 0.01);
            } else {
                this.center.setX(info.collisionPoint().getX() + 0.01);
            }
             if (trajectory.end().getY() - trajectory.start().getY() > 0) {
                this.center.setY(info.collisionPoint().getY() - 0.01);
            } else {
                this.center.setY(info.collisionPoint().getY() + 0.01);
            }
            this.velocity = info.collisionObject().hit(info.collisionPoint(), this.velocity);
        }
    }
 }
