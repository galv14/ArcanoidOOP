/**
 *
 * @author gal.
 *
 */
public class CollisionInfo {
    private Point point;
    private Collidable c;
    /**
     *
     * @param p a Point
     * @param c a Collidable
     */
    public CollisionInfo(Point p, Collidable c) {
        this.point = p;
        this.c = c;
    }
   // the point at which the collision occurs.
    /**
     *
     * @return the point at which the collision occurs.
     */
   public Point collisionPoint() {
       return this.point;
   }

   // the collidable object involved in the collision.
   /**
    *
    * @return collidable object involved in the collision.
    */
   public Collidable collisionObject() {
       return this.c;
   }
}
