package sprites;

import biuoop.DrawSurface;
/**
 *
 * @author gal.
 *
 */
public class Backgruond3 implements Sprite {

    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(java.awt.Color.green.darker().darker());
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(java.awt.Color.GRAY);
        d.fillRectangle(146, 240, 10, 150);
        d.setColor(java.awt.Color.DARK_GRAY);
        d.fillRectangle(130, 390, 40, 70);
        d.setColor(java.awt.Color.DARK_GRAY.darker());
        d.fillRectangle(100, 460, 110, 140);
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                d.setColor(java.awt.Color.WHITE);
                d.fillRectangle(110 + j * 20, 470 + i * 40, 10, 30);
            }
        }
        d.setColor(java.awt.Color.orange.darker());
        d.fillCircle(150, 240, 14);
        d.setColor(java.awt.Color.getHSBColor(40, 60, 161));
        d.fillCircle(150, 240, 9);
        d.setColor(java.awt.Color.white);
        d.fillCircle(150, 240, 4);
    }

    @Override
    public void timePassed(double dt) { }

}


