package sprites;

import biuoop.DrawSurface;
/**
 *
 * @author gal.
 *
 */
public class Backgruond1 implements Sprite {

    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(java.awt.Color.BLACK);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(java.awt.Color.blue);
        d.drawCircle(415, 215, 150);
        d.drawCircle(415, 215, 100);
        d.drawCircle(415, 215, 50);
        d.drawLine(240, 215, 380, 215);
        d.drawLine(450, 215, 590, 215);
        d.drawLine(415, 40, 415, 180);
        d.drawLine(415, 250, 415, 390);
    }

    @Override
    public void timePassed(double dt) { }

}
