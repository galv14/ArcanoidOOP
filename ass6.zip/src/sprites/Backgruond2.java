package sprites;

import biuoop.DrawSurface;
/**
 *
 * @author gal.
 *
 */
public class Backgruond2 implements Sprite {

    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(java.awt.Color.white);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(java.awt.Color.getHSBColor(40, 60, 159));
        for (int i = 0; i < 50; i++) {
            d.drawLine(150, 130, 0 + i * 20, 230);
        }
        d.fillCircle(150, 130, 55);
        d.setColor(java.awt.Color.getHSBColor(40, 60, 153));
        d.fillCircle(150, 130, 40);
        d.setColor(java.awt.Color.yellow);
        d.fillCircle(150, 130, 30);

    }

    @Override
    public void timePassed(double dt) { }

}

