package levels;

import java.util.ArrayList;
import java.util.List;

import shapes.Rectangle;
import sprites.Backgruond1;
import sprites.Block;
import sprites.Sprite;
import sprites.Velocity;
/**
 *
 * @author gal.
 *
 */
public class DirectHit implements LevelInformation {
    private List<Velocity> listV;
    private List<Block> listB;
    /**
     *
     */
    public DirectHit() {
        this.listV = new ArrayList<Velocity>();
        this.listB = new ArrayList<Block>();
    }

    @Override
    public int numberOfBalls() {
        return 1;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
       // Velocity v = new Velocity(410, 500);
        //this.listV.add(v);
        Velocity v = Velocity.fromAngleAndSpeed(0, 480);
        this.listV.add(v);
        return listV;
    }

    @Override
    public int paddleSpeed() {
        return 300;
    }

    @Override
    public int paddleWidth() {
        return 100;
    }

    @Override
    public String levelName() {
        return "Direct Hit";
    }

    @Override
    public Sprite getBackground() {
        Backgruond1 x = new Backgruond1();
        return x;
    }

    @Override
    public List<Block> blocks() {
        Block block = new Block(new Rectangle(400, 200, 30, 30));
        block.getCollisionRectangle().setColor(java.awt.Color.red);
        block.setHit(1);
        this.listB.add(block);
        return listB;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return 1;
    }

}
