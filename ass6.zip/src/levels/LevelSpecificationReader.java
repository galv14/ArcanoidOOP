package levels;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;




/**
 *
 * @author gal.
 *
 */
public class LevelSpecificationReader {
    private List<LevelInformation> list;
    //private File file;
    /**
     *
     */
    public LevelSpecificationReader() {
        this.list = new ArrayList<LevelInformation>();
        //this.file = filename;
    }
    /**
     *
     * @param reader a java.io.Reader
     * @return a List<LevelInformation>
     */
   /* public List<TreeMap<String, String>> fromFileToString(java.io.Reader reader) {
        List<TreeMap<String, String>> treeList = new LinkedList<TreeMap<String, String>>();
        //List<List<String>> levelsList = new LinkedList<List<String>>();
        Scanner br = null;
        br = new Scanner(reader);
        int i;
        String line;
        while (br.hasNextLine()) {
            line = br.nextLine();
            if (line.equals("START_LEVEL")) {
                //List<String> lStrings = new LinkedList<String>();
                TreeMap<String, String> tree = new TreeMap<String, String>();
                line = br.nextLine();
                while (!line.equals("END_LEVEL")) {
                    if (!line.startsWith("#") && !line.isEmpty()) {
                        String[] parts = line.split(": ");
                        for (i = 1; i < parts.length; i++) {
                            tree.put(parts[0], parts[i]);
                        }
                    }
                    line = br.nextLine();
                }
                treeList.add(tree);
            }
        }
        br.close();
        return treeList;
     }*/
    /**
     *
     * @param reader a java.io.Reader
     * @return a List<LevelInformation>
     * @throws IOException Exeption
     */
    public List<LevelInformation> fromReader(java.io.Reader reader) throws IOException {
        List<List<String>> levels = levelsList(reader);
       // System.out.println(levels);
        for (int i = 0; i < levels.size(); i++) {
            LevelInformation aLevel = new NewLevel(levels.get(i));
            this.list.add(aLevel);
        }
        return this.list;
    }
    /**
     *
     * @param reader a java.io.Reader
     * @return List<List<String>>
     */
    public List<List<String>> levelsList(java.io.Reader reader) {
        List<List<String>> levels = new ArrayList<List<String>>();
        Scanner br = null;
        br = new Scanner(reader);
        String line;
        while (br.hasNextLine()) {
            line = br.nextLine();
            if (line.equals("START_LEVEL")) {
                List<String> lStrings = new ArrayList<String>();
                line = br.nextLine();
                while (!line.equals("END_LEVEL")) {
                    if (!line.startsWith("#") && !line.isEmpty()) {
                        lStrings.add(line);
                    }
                    line = br.nextLine();
                }
                levels.add(lStrings);
               // System.out.println(levels);
            }
        }
        br.close();
       // System.out.println(levels.size());
        return levels;
    }
}
