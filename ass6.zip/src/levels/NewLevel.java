package levels;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import sprites.Block;
import sprites.Sprite;
import sprites.Velocity;
/**
 *
 * @author gal.
 *
 */
public class NewLevel implements LevelInformation {
    private List<String> lStrings;
    private TreeMap<String, String> tree;
    private List<String> symbols;
    /**
     *
     * @param lStrings a List<String>
     * @throws IOException Exeption
     */
    public NewLevel(List<String> lStrings) throws IOException {
        this.lStrings = lStrings;
        this.tree = new TreeMap<String, String>();
        setLevel();
        //System.out.println(this.tree);
        //System.out.println(this.symbols.get(0).charAt(0));
       // System.out.println(this.tree.get("block_definitions"));
        String r = "resources/";
        File file = new File(r.concat(this.tree.get("block_definitions")));
        try {
            java.io.Reader reader = new InputStreamReader(new FileInputStream(file), "utf-8");
            //BlocksDefinitionReader qw = new BlocksDefinitionReader();
            reader.close();
        } catch (UnsupportedEncodingException | FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    @Override
    public int numberOfBalls() {
        int count = 0;
        String[] parts = this.tree.get("ball_velocities").split(" ");
        for (int i = 0; i < parts.length; i++) {
            count++;
        }
        return count;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> listV = new ArrayList<Velocity>();
        String[] parts = this.tree.get("ball_velocities").split(" ");
        for (int i = 0; i < parts.length; i++) {
            String [] velocities = parts[i].split(",");
            Velocity v = Velocity.fromAngleAndSpeed(Integer.parseInt(velocities[0]), Integer.parseInt(velocities[1]));
            listV.add(v);
        }
        return listV;
    }

    @Override
    public int paddleSpeed() {
        return Integer.parseInt(this.tree.get("paddle_speed"));
    }

    @Override
    public int paddleWidth() {
        return Integer.parseInt(this.tree.get("paddle_width"));
    }

    @Override
    public String levelName() {
        return this.tree.get("level_name");
    }

    @Override
    public Sprite getBackground() {
        NewBackgruond x = new NewBackgruond(this.tree.get("background"));
        return x;
    }

    @Override
    public List<Block> blocks() {
        int blockStartX = Integer.parseInt(this.tree.get("blocks_start_x"));
        int blockStartY = Integer.parseInt(this.tree.get("blocks_start_y"));
        int rowHight = Integer.parseInt(this.tree.get("row_height"));
        List<Block> blocksList = new ArrayList<Block>();
        String r = "resources/";
        File file = new File(r.concat(this.tree.get("block_definitions")));
        BlocksFromSymbolsFactory blocksFactory;
        try {
            java.io.Reader reader = new InputStreamReader(new FileInputStream(file), "utf-8");
            //BlocksDefinitionReader bDR = new BlocksDefinitionReader();
            blocksFactory = BlocksDefinitionReader.fromReader(reader);
            for (int i = 0; i < this.symbols.size(); i++) {
                int space = 0;
                int count = 0;
                for (int j = 0; j < this.symbols.get(i).length(); j++) {
                    if (blocksFactory.isBlockSymbol(String.valueOf(this.symbols.get(i).charAt(j)))) {
                        //int height = blocksFactory.getHeight(String.valueOf(this.symbols.get(i).charAt(j)));
                        int width = blocksFactory.getWidth(String.valueOf(this.symbols.get(i).charAt(j)));
                        //System.out.println( count*width);
                        blocksList.add(blocksFactory.getBlock(String.valueOf(this.symbols.get(i).charAt(j)),
                                blockStartX + space + count * width, blockStartY + i * rowHight));
                        //space = 0;
                        count++;
                    }
                    if (blocksFactory.isSpaceSymbol(String.valueOf(this.symbols.get(i).charAt(j)))) {
                       space += blocksFactory.getSpaceWidth(String.valueOf(this.symbols.get(i).charAt(j)));
                       //System.out.println(space);
                    }
                }
            }
            return blocksList;
           // blocksFactory.getBlock(, blockStartX, blockStartY)
        } catch (UnsupportedEncodingException | FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return Integer.parseInt(this.tree.get("num_blocks"));
    }
    /**
     *
     */
    public void setLevel() {
        int i = 0;
        int j;
        while (!this.lStrings.get(i).equals("START_BLOCKS")) {
            if (!this.lStrings.get(i).startsWith("#") && !this.lStrings.get(i).isEmpty()) {
                String[] parts = this.lStrings.get(i).split(":");
                    tree.put(parts[0], parts[1]);
            }
            i++;
        }
        i++;
        j = i;
        while (!this.lStrings.get(j).equals("END_BLOCKS")) {
            j++;
        }
        this.symbols = lStrings.subList(i, j);
    }
}
