package levels;

import java.util.ArrayList;
import java.util.List;

import shapes.Rectangle;
import sprites.Backgruond3;
import sprites.Block;
import sprites.Sprite;
import sprites.Velocity;

/**
 *
 * @author gal
 *
 */
public class Green3 implements LevelInformation {
    private List<Velocity> listV;
    private List<Block> listB;
    /**
     *
     */
    public Green3() {
        this.listV = new ArrayList<Velocity>();
        this.listB = new ArrayList<Block>();
    }

    @Override
    public int numberOfBalls() {
        return 2;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        Velocity v;
        v = Velocity.fromAngleAndSpeed(315, 420);
        this.listV.add(v);
        v = Velocity.fromAngleAndSpeed(45, 420);
        this.listV.add(v);
        return listV;
    }

    @Override
    public int paddleSpeed() {
        return 720;
    }

    @Override
    public int paddleWidth() {
        return 100;
    }

    @Override
    public String levelName() {
        return "Green3";
    }

    @Override
    public Sprite getBackground() {
        Backgruond3 x = new Backgruond3();
        return x;
    }

    @Override
    public List<Block> blocks() {
        int i;
        Block block = null;
        int count = 50;
        for (i = 0; i < 10; i++) {
            block = new Block(new Rectangle(768 - ((i + 1) * count), 180, count, 30));
            block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
            block.setHit(2);
            this.listB.add(block);
        }
        for (i = 0; i < 9; i++) {
            block = new Block(new Rectangle(768 - ((i + 1) * count), 210, count, 30));
            block.getCollisionRectangle().setColor(java.awt.Color.RED);
            block.setHit(1);
            this.listB.add(block);
        }
        for (i = 0; i < 8; i++) {
            block = new Block(new Rectangle(768 - ((i + 1) * count), 240, count, 30));
            block.getCollisionRectangle().setColor(java.awt.Color.YELLOW);
            block.setHit(1);
            this.listB.add(block);
        }
        for (i = 0; i < 7; i++) {
            block = new Block(new Rectangle(768 - ((i + 1) * count), 270, count, 30));
            block.getCollisionRectangle().setColor(java.awt.Color.BLUE);
            block.setHit(1);
            this.listB.add(block);
        }
        for (i = 0; i < 6; i++) {
            block = new Block(new Rectangle(768 - ((i + 1) * count), 300, count, 30));
            block.getCollisionRectangle().setColor(java.awt.Color.WHITE);
            block.setHit(1);
            this.listB.add(block);
        }
        //Block block = new Block(new Rectangle(400, 200, 30, 30));
        //this.listB.add(block);
        return listB;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return 40;
    }

}
