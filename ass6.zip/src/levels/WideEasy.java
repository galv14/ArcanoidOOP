package levels;

import java.util.ArrayList;
import java.util.List;

import shapes.Rectangle;
import sprites.Backgruond2;
import sprites.Block;
import sprites.Sprite;
import sprites.Velocity;
/**
 *
 * @author gal.
 *
 */
public class WideEasy implements LevelInformation {
    private List<Velocity> listV;
    private List<Block> listB;
    /**
     *
     */
    public WideEasy() {
        this.listV = new ArrayList<Velocity>();
        this.listB = new ArrayList<Block>();
    }

    @Override
    public int numberOfBalls() {
        return 10;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        int i;
        int j = 0;
        Velocity v;
        for (i = 0; i < 10; i++) {
            if (i > 4) {
                j = 8;
            }
            v = Velocity.fromAngleAndSpeed(291 + i * 14 + j, 420);
            this.listV.add(v);
        }
        return listV;
    }
    @Override
    public int paddleSpeed() {
        return 60;
    }

    @Override
    public int paddleWidth() {
        return 600;
    }

    @Override
    public String levelName() {
        return "Wide Easy";
    }

    @Override
    public Sprite getBackground() {
        Backgruond2 x = new Backgruond2();
        return x;
    }

    @Override
    public List<Block> blocks() {
        int i;
        Block block = null;
        for (i = 0; i < 15; i++) {
            block = new Block(new Rectangle(32 + 49 * i, 225, 49, 32));
            if (i >= 0 && i < 2) {
                block.getCollisionRectangle().setColor(java.awt.Color.RED);
            } else if (i >= 2 && i < 4) {
                block.getCollisionRectangle().setColor(java.awt.Color.ORANGE);
            } else if (i >= 4 && i < 6) {
                block.getCollisionRectangle().setColor(java.awt.Color.yellow);
            } else if (i >= 6 && i < 9) {
                block.getCollisionRectangle().setColor(java.awt.Color.GREEN);
            } else if (i >= 9 && i < 11) {
                block.getCollisionRectangle().setColor(java.awt.Color.BLUE);
            } else if (i >= 11 && i < 13) {
                block.getCollisionRectangle().setColor(java.awt.Color.PINK);
            } else { block.getCollisionRectangle().setColor(java.awt.Color.cyan); }
            block.setHit(1);
            this.listB.add(block);
        }
        //Block block = new Block(new Rectangle(400, 200, 30, 30));
        //this.listB.add(block);
        return listB;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return 15;
    }

}
