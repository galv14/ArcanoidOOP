package levels;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import javax.imageio.ImageIO;

/**
 *
 * @author gal.
 *
 */
public class BlocksDefinitionReader {
    //private List<BlocksFromSymbolsFactory> list;
    /**
     *
     */
    public BlocksDefinitionReader() {
        //fromReader(reader);
    }
    /**
     *
     * @param reader a java.io.Reader
     * @return BlocksFromSymbolsFactory
     */
    public static BlocksFromSymbolsFactory fromReader(java.io.Reader reader) {
        Scanner br = new Scanner(reader);
        String line;
        String[] default1 = null;
        String[] information = null;
        String symbol = null;
        String[] num = null;
        Map<String, BlockCreator> blockCreators = new TreeMap<String, BlockCreator>();
        Map<String, Integer> spacerWidths = new TreeMap<String, Integer>();
        Map<String, Integer> blocksWidths = new TreeMap<String, Integer>();
        Map<String, Integer> blocksheight = new TreeMap<String, Integer>();
        TreeMap<String, Image> blockImage = null;
        //List<BlocksFromSymbolsFactory> list = new ArrayList<BlocksFromSymbolsFactory>();
        while (br.hasNextLine()) {
            line = br.nextLine();
           // System.out.println(line);
            if (!line.startsWith("#") && !line.isEmpty()) {
                if (line.startsWith("default")) {
                    default1 = line.substring(8).split(" ");
                    //System.out.println(line.substring(8));
                }
                if (line.startsWith("bdef")) {
                    information = line.substring(5).split(" ");
                    for (int i = 0; i < information.length; i++) {
                        if (information[i].startsWith("symbol")) {
                            symbol = information[i].substring(7);
                        }
                       // System.out.println(line.substring(5));
                    }
                    TreeMap<String, String> tree = setInfo(information, default1);
                    ANewBlock x = new ANewBlock(tree, getImage(tree));
                    blocksWidths.put(symbol, x.getWidth());
                    blocksheight.put(symbol, x.getWidth());
                    blockCreators.put(symbol, x);
                }
                if (line.startsWith("sdef")) {
                    information = line.substring(5).split(" ");
                    for (int i = 0; i < information.length; i++) {
                        if (information[i].startsWith("symbol")) {
                            symbol = information[i].substring(7);
                            //System.out.println(symbol);
                        }
                        if (information[i].startsWith("width")) {
                            num = information[i].split(":");
                            //System.out.println(num[1]);
                        }
                    }
                    spacerWidths.put(symbol, Integer.parseInt(num[1]));
                }
            }
            //line = br.nextLine();
        }
        br.close();
        return new BlocksFromSymbolsFactory(spacerWidths, blockCreators, blocksWidths, blocksheight, blockImage);
    }
    /**
     *
     * @param tree a TreeMap<String, String>
     * @return a TreeMap<String, Image>
     */
    public static TreeMap<String, Image> getImage(TreeMap<String, String> tree) {
        TreeMap<String, Image> blockImage = new TreeMap<String, Image>();
        int i = Integer.parseInt(tree.get("hit_points"));
        for (int j = 1; j <= i; j++) {
            if (tree.containsKey(Integer.toString(j))) {
                if (tree.get(Integer.toString(j)).startsWith("image")) {
                    Image img = null;
                    String imgName = tree.get(Integer.toString(j)).substring(6,
                            tree.get(Integer.toString(j)).length() - 1);
                    try {
                        img = ImageIO.read(new File("resources/".concat(imgName)));
                        blockImage.put(Integer.toString(j), img);
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }
        if (tree.containsKey("fill")) {
            if (tree.get("fill").startsWith("image")) {
                Image img = null;
                String imgName = tree.get("fill").substring(6, tree.get("fill").length() - 1);
                try {
                    img = ImageIO.read(new File("resources/".concat(imgName)));
                    blockImage.put("fill", img);
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        return blockImage;
    }
       /* TreeMap<String, Image> blockImage = new TreeMap<String, Image>();
        Image img = null;
        String imgName = "resources/".concat(image);
        try {
            img = ImageIO.read(new File(imgName));
            blockImage.put(type, img);
            return blockImage;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }*/
    /**
     *
     * @param info a String[]
     * @param defaultInfo a String[]
     * @return a TreeMap<String, String>
     */
    public static TreeMap<String, String> setInfo(String[] info, String[] defaultInfo) {
        TreeMap<String, String> tree = new TreeMap<String, String>();
        int i;
        if (defaultInfo != null) {
            for (i = 0; i < defaultInfo.length; i++) {
                String[] defaultInformation = defaultInfo[i].split(":");
                if (defaultInfo[i].startsWith("fill-")) {
                    defaultInformation[0] = defaultInformation[0].substring(5);
                }
                tree.put(defaultInformation[0], defaultInformation[1]);
            }
        }
        for (i = 0; i < info.length; i++) {
            String[] defaultInformation = info[i].split(":");
            if (info[i].startsWith("fill-")) {
                defaultInformation[0] = defaultInformation[0].substring(5);
            }
            if (tree.containsKey(defaultInformation[0])) {
                tree.remove(defaultInformation[0]);
            }
            tree.put(defaultInformation[0], defaultInformation[1]);
        }
        return tree;
    }
}
