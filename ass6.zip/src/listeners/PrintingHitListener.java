package listeners;
import sprites.Ball;
import sprites.Block;
/**
 *
 * @author gal.
 *
 */
public class PrintingHitListener implements HitListener {
    /**
     *
     */
    public PrintingHitListener() { }
    /**
     *
     * @param beingHit a Block
     * @param hitter a Ball
     *
     */
   public void hitEvent(Block beingHit, Ball hitter) {
      System.out.println("A Block with " + beingHit.getHit() + " points was hit.");
   }
}