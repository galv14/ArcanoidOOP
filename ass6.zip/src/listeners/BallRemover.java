package listeners;

import game.Counter;
import game.GameLevel;
import sprites.Ball;
import sprites.Block;

/**
 *
 * @author gal.
 *
 */
public class BallRemover implements HitListener {
    private GameLevel gameLevel;
    private Counter remainingBalls;
    /**
     *
     * @param gameLevel a Game
     * @param remainingBalls a Counter
     */
    public BallRemover(GameLevel gameLevel, Counter remainingBalls) {
        this.gameLevel = gameLevel;
        this.remainingBalls = remainingBalls;
    }
    /**
    *
    * @param beingHit a Block
    * @param hitter a Ball
    *
    */
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(gameLevel);
        remainingBalls.decrease(1);
    }

}
