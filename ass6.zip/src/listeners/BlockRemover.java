package listeners;

import game.Counter;
import game.GameLevel;
import sprites.Ball;
import sprites.Block;

/**
 *
 * @author gal.
 *
 */
public class BlockRemover implements HitListener {
    private GameLevel gameLevel;
    private Counter remainingBlocks;
    /**
     *
     * @param gameLevel a Game
     * @param removedBlocks a Counter
     */
    public BlockRemover(GameLevel gameLevel, Counter removedBlocks) {
        this.gameLevel = gameLevel;
        this.remainingBlocks = removedBlocks;
    }
    // Blocks that are hit and reach 0 hit-points should be removed
    // from the game. Remember to remove this listener from the block
    // that is being removed from the game.
    /**
     *
     * @param beingHit a Block
     * @param hitter a Ball
     *
     */
    public void hitEvent(Block beingHit, Ball hitter) {
       // System.out.println(beingHit.getHit());
        if (beingHit.getHit().equalsIgnoreCase("1")) {
            beingHit.removeFromGame(gameLevel);
            beingHit.removeHitListener(this);
            remainingBlocks.decrease(1);
        }
    }
 }
