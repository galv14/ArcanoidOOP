package menu;

import animation.Animation;

/**
 *
 * @author gal.
 *
 * @param <T> generic
 */
public interface Menu<T> extends Animation {
    /**
     *
     * @param key a key to wait for
     * @param message a line to print
     * @param returnVal what to return
     */
    void addSelection(String key, String message, T returnVal);
    /**
     *
     * @return which option selected
     */
    T getStatus();
    /**
     *
     * @param key a key to wait for
     * @param message a line to print
     * @param subMenu a Menu<T>
     */
    void addSubMenu(String key, String message, Menu<T> subMenu);
 }
