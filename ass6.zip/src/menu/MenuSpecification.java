package menu;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author gal.
 *
 */
public class MenuSpecification {
    /**
     *
     */
    public MenuSpecification() {
    }
    /**
     *
     * @param reader a v
     * @return a List<String>
     * @throws IOException Exception
     */
    public List<String> fromReader(java.io.Reader reader) throws IOException {
        List<String> lStrings = new ArrayList<String>();
        Scanner br = null;
        br = new Scanner(reader);
        String line;
        while (br.hasNextLine()) {
            line = br.nextLine();
            if (!line.isEmpty()) {
                if (line.contains(":")) {
                    String[] information = line.split(":");
                    lStrings.add(information[0]);
                    lStrings.add(information[1]);
                    line = br.nextLine();
                }
                lStrings.add(line);
            }
        }
        br.close();
        return lStrings;
    }
}
