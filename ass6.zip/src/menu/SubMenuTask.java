package menu;

import animation.AnimationRunner;
/**
 *
 * @author gal.
 *
 */
public class SubMenuTask implements Task<Void> {
    private AnimationRunner runner;
    private Menu<Task<Void>> menu;
    /**
     *
     * @param runner an AnimationRunner
     * @param menu a Menu<Task<Void>>
     */
    public SubMenuTask(AnimationRunner runner, Menu<Task<Void>> menu) {
        this.runner = runner;
        this.menu = menu;
    }
    @Override
    public Void run() {
        runner.run(menu);
        Task<Void> task = menu.getStatus();
        task.run();
        return null;
    }

}
