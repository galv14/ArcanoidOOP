package menu;

import java.util.List;

import game.GameFlow;
import levels.LevelInformation;
/**
 *
 * @author gal.
 *
 */
public class RunTask implements Task<Void> {
    private GameFlow flow;
    private List<LevelInformation> levels;
    /**
     *
     * @param flow a GameFlow
     * @param levels a List<LevelInformation>
     */
    public RunTask(GameFlow flow, List<LevelInformation> levels) {
        this.flow = flow;
        this.levels = levels;
    }
    @Override
    public Void run() {
        flow.runLevels(levels);
        return null;
    }

}
