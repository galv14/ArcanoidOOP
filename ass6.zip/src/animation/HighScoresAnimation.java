package animation;

import biuoop.DrawSurface;
import highscore.HighScoresTable;

/**
 *
 * @author gal.
 *
 */
public class HighScoresAnimation implements Animation {
    private HighScoresTable scores;
    private String endKey;
    /**
     *
     * @param scores a HighScoresTable
     * @param endKey a String
     *
     *
     */
    public HighScoresAnimation(HighScoresTable scores, String endKey) {
        this.scores = scores;
        this.endKey = endKey;
    }
    @Override
    public void doOneFrame(DrawSurface d, double dt) {
        d.drawText(200, 45, "HIGH SCORES TABLE", 50);
        for (int i = 0; i < this.scores.getCounter(); i++) {
            d.drawText(10, d.getHeight() / 4 + 25 * i, "Rank: " + (i + 1) + ", Name: "
        + this.scores.getHighScores().get(i).getName() + ", Score: "
                    + this.scores.getHighScores().get(i).getScore(), 32);
        }
        d.drawText(200, 550, "press  '" + this.endKey + "'  to exit", 25);
        //if (this.keyboard.isPressed(this.endKey)) { this.stop = true; }
        //super.doOneFrame(d, dt);
    }

    @Override
    public boolean shouldStop() { return true; }

}
