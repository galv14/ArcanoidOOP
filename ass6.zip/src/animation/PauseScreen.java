package animation;
import biuoop.DrawSurface;

/**
 *
 * @author gal.
 *
 */
public class PauseScreen implements Animation {
   // private KeyboardSensor keyboard;
   // private boolean stop;
    /**
     *
     *
     */
    public PauseScreen() {
       //this.keyboard = k;
       //this.stop = false;
    }
    @Override
    public void doOneFrame(DrawSurface d, double dt) {
       d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
    }
    @Override
    public boolean shouldStop() { return true; }
 }
