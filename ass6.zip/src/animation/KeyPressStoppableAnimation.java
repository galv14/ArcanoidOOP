package animation;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

/**
 *
 * @author gal.
 *
 */
public class KeyPressStoppableAnimation implements Animation {
    private KeyboardSensor keyboard;
    private String key;
    private Animation animation;
    private boolean stop;
    private boolean isAlreadyPressed;
    /**
     *
     * @param sensor a KeyboardSensor
     * @param key a String
     * @param animation an Animation
     */
    public KeyPressStoppableAnimation(KeyboardSensor sensor, String key, Animation animation) {
        this.keyboard = sensor;
        this.key = key;
        this.animation = animation;
        this.stop = false;
        this.isAlreadyPressed = true;
    }

    @Override
    public void doOneFrame(DrawSurface d, double dt) {
       // this.animation.doOneFrame(d, dt);
        this.animation.doOneFrame(d, dt);
        if (this.keyboard.isPressed(this.key)) {
            if (!this.isAlreadyPressed) {
                this.stop = true;
            }
        } else {
        this.isAlreadyPressed = false;
        }
    }

    @Override
    public boolean shouldStop() {
        this.animation.shouldStop();
        return this.stop; }
}
