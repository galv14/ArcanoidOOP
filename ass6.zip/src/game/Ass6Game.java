package game;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import animation.Animation;
import animation.AnimationRunner;
import animation.HighScoresAnimation;
import animation.KeyPressStoppableAnimation;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import highscore.HighScoresTable;
import levels.LevelInformation;
import levels.LevelSpecificationReader;
import menu.ExitTask;
import menu.Menu;
import menu.MenuAnimation;
import menu.MenuSpecification;
import menu.RunTask;
import menu.ShowHiScoresTask;
import menu.SubMenuTask;
import menu.Task;

/**
 *
 * @author gal.
 *
 */
public class Ass6Game {
    public static final String TABLEKEY = "e";
    /**
     *
     * @param args user
     */
    public static void main(String[] args) {
        GUI gui = new GUI("Arkanoid", 800, 600);
        AnimationRunner ar = new AnimationRunner(gui);
        KeyboardSensor ks = gui.getKeyboardSensor();
        File highscores = new File("highScore");
        File file = null;
        if (args.length == 1) {
           file = new File("resources/" + args[0]);
           //System.out.println("in");
        } else {
            file = new File("resources/definitions/Level-Sets.txt");
       }
        boolean user = false;
        //System.out.println(file);
        try {
            java.io.Reader reader = new InputStreamReader(new FileInputStream(file), "utf-8");
            MenuSpecification main = new MenuSpecification();
            try {
                List<String> lStrings = main.fromReader(reader);
                while (true) {
                    try {
                        GameFlow flow = new GameFlow(ar, ks, gui, highscores);
                        HighScoresTable highScoreTable = HighScoresTable.loadFromFile(highscores);
                        Animation hSAnimation = new HighScoresAnimation(highScoreTable, TABLEKEY);
                        Menu<Task<Void>> menu = new MenuAnimation<Task<Void>>("arkanoid", ks);
                        Menu<Task<Void>> subMenu = new  MenuAnimation<Task<Void>>("Level Sets", ks);
                        menu.addSelection("s", "Press 's' to start a new game.", new SubMenuTask(ar, subMenu));
                        menu.addSelection("h", "Press 'h' to see the high scores.",
                                new ShowHiScoresTask(ar, new KeyPressStoppableAnimation(ks, TABLEKEY, hSAnimation)));
                        menu.addSelection("q", "Press 'q' to quit.", new ExitTask(gui));
                        for (int i = 0; i < lStrings.size(); i += 3) {
                            if (args.length < 0) {
                               // if (args[1].equals(lStrings.get(i))) {
                                    LevelSpecificationReader x = new LevelSpecificationReader();
                                    File levelFile = new File("resources/" + args[0]);
                                    java.io.Reader levelReader =
                                            new InputStreamReader(new FileInputStream(levelFile), "utf-8");
                                    List<LevelInformation> levels = x.fromReader(levelReader);
                                    subMenu.addSelection(lStrings.get(i),
                                            lStrings.get(i + 1), new RunTask(flow, levels));
                                    user = true;
                                    break;
                               // }
                            }
                        }
                        if (!user) {
                            for (int i = 0; i < lStrings.size(); i += 3) {
                                LevelSpecificationReader x = new LevelSpecificationReader();
                                File levelFile = new File(lStrings.get(i + 2));
                                java.io.Reader levelReader =
                                        new InputStreamReader(new FileInputStream(levelFile), "utf-8");
                                List<LevelInformation> levels = x.fromReader(levelReader);
                                subMenu.addSelection(lStrings.get(i), lStrings.get(i + 1), new RunTask(flow, levels));
                                //levelReader = null;
                            }
                        }
                        menu.addSubMenu("a", "sub menu", subMenu);
                        ar.run(menu);
                        // wait for user selection
                        Task<Void> task = menu.getStatus();
                        task.run();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (UnsupportedEncodingException | FileNotFoundException e) {
            e.printStackTrace();
        }
     }
}
