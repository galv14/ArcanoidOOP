package game;

import java.io.File;
import java.io.IOException;
import java.util.List;

import animation.Animation;
import animation.AnimationRunner;
import animation.EndScreen;
import animation.HighScoresAnimation;
import animation.KeyPressStoppableAnimation;
import biuoop.DialogManager;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import highscore.HighScoresTable;
import highscore.ScoreInfo;
import levels.LevelInformation;
/**
 *
 * @author gal.
 *
 */
public class GameFlow {
    public static final String TABLEKEY = "e";
    private AnimationRunner animationRunner;
    private KeyboardSensor keyboardSensor;
    private GUI gui;
    private File highscores;
    private HighScoresTable highScoreTable;
    /**
     *
     * @param ar an AnimationRunner
     * @param ks a KeyboardSensor
     * @param gui a GUI
     * @param highscore a File
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, GUI gui, File highscore) {
        this.animationRunner = ar;
        this.keyboardSensor = ks;
        this.gui = gui;
        this.highscores = highscore;
        this.highScoreTable = HighScoresTable.loadFromFile(this.highscores);
    }
    /**
     *
     * @param levels a List<LevelInformation>
     */
    public void runLevels(List<LevelInformation> levels) {
        Counter score = new Counter();
        Counter lives = new Counter();
        boolean win = true;
        Animation hSAnimation = new HighScoresAnimation(this.highScoreTable, TABLEKEY);
        DialogManager dialog = gui.getDialogManager();
        lives.increase(42);
        for (LevelInformation levelInfo : levels) {
            GameLevel level = new GameLevel(levelInfo,
                  this.keyboardSensor,
                  this.animationRunner, this.gui, score, lives);

            level.initialize();

            while (level.getBlocksCounter().getValue() > 0 && level.getLivesCounter().getValue() > 0) {
               level.playOneTurn();
               if (level.getBallsCounter().getValue() == 0) {
                   lives.decrease(1);
               }
            }
            if (level.getLivesCounter().getValue() == 0) {
                win = false;
               break;
           }
         }
        this.animationRunner.run(new KeyPressStoppableAnimation(this.keyboardSensor, KeyboardSensor.SPACE_KEY,
                (new EndScreen(score, win))));
        if (this.highScoreTable.getRank(score.getValue()) < this.highScoreTable.size()) {
            ScoreInfo x;
            String name = dialog.showQuestionDialog("Name", "What is your name?", "");
            x = new ScoreInfo(name, score.getValue());
            this.highScoreTable.add(x);
            try {
             this.highScoreTable.save(highscores);
         } catch (IOException e) {
             e.printStackTrace();
         }
            //System.out.println(name);
        }
        this.animationRunner.run(new KeyPressStoppableAnimation(this.keyboardSensor, TABLEKEY,
                (hSAnimation)));
     }
 }
