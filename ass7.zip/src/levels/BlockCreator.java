package levels;

import sprites.Block;

/**
 *
 * @author gal.
 *
 */
public interface BlockCreator {
    // Create a block at the specified location.
    /**
     *
     * @param xpos x position
     * @param ypos y position
     * @return a Block
     */
    Block create(int xpos, int ypos);
 }
