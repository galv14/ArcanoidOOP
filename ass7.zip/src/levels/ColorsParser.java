package levels;

import java.awt.Color;
/**
 *
 * @author gal.
 *
 */
public class ColorsParser {
    /**
     *
     */
    public ColorsParser() { }
    // parse color definition and return the specified color.
    /**
     *
     * @param s a String
     * @return a Color
     */
    public java.awt.Color colorFromString(String s) {
        if (s.startsWith("color(RGB")) {
            String[] names = s.substring(10, s.length() - 2).split(",");
            Color color = new Color(Integer.parseInt(names[0]), Integer.parseInt(names[1]), Integer.parseInt(names[2]));
            return color;
        }
        String name = s.substring(6, s.length() - 1);
        try {
            Color aColor   = (Color) Color.class.getField(name).get(null);
            return aColor;
        } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
}
