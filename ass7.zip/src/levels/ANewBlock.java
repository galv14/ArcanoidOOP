package levels;

import java.awt.Image;
import java.util.TreeMap;

import shapes.Rectangle;
import sprites.Block;
/**
 *
 * @author gal.
 *
 */
public class ANewBlock implements BlockCreator {
    private int width;
    private int height;
    private TreeMap<String, String> tree;
    private TreeMap<String, Image> imageTree;
    //private ColorsParser colors;
    /**
     *
     * @param imageTree a TreeMap<String, Image>
     * @param tree a TreeMap<String, String>
     */
    public ANewBlock(TreeMap<String, String> tree, TreeMap<String, Image> imageTree) {
        //this.info = info;
        //this.defaultInfo = defaultInfo;
        //this.image = null;
        this.tree = tree;
        this.imageTree = imageTree;
        set();
       // this.colors = new ColorsParser();
    }

    @Override
    public Block create(int xpos, int ypos) {
        Block block = new Block(new Rectangle(xpos, ypos, Integer.parseInt(tree.get("width")),
                Integer.parseInt(tree.get("height"))));
        block.setTree(tree, imageTree);
        block.setHit(Integer.parseInt(tree.get("hit_points")));
        return block;
    }
    /**
     *
     * @return an int
     */
    public int getWidth() {
        return this.width;
    }
    /**
    *
    * @return an int
    */
    public int getHeight() {
        return this.height;
    }
    /*public String getImage() {
        if(this.image != null) {
            return this.image.substring(6, this.image.length() - 1);
        }
        return null;
    }*/
    /**
     *
     */
    public void set() {
       /** int i;
        //String imgName;
        this.tree = new TreeMap<String, String>();
        //System.out.println(this.defaultInfo.length);
        if (this.defaultInfo != null) {
            for (i = 0; i < this.defaultInfo.length; i++) {
                String[] defaultInformation = this.defaultInfo[i].split(":");
                if (this.defaultInfo[i].startsWith("fill-")) {
                    defaultInformation[0] = defaultInformation[0].substring(5);
                }
                tree.put(defaultInformation[0], defaultInformation[1]);
            }
        }
        for (i = 0; i < this.info.length; i++) {
            String[] defaultInformation = this.info[i].split(":");
            if (this.info[i].startsWith("fill-")) {
                defaultInformation[0] = defaultInformation[0].substring(5);
            }
            if (tree.containsKey(defaultInformation[0])) {
                tree.remove(defaultInformation[0]);
            }
            tree.put(defaultInformation[0], defaultInformation[1]);
        }*/
        this.width = Integer.parseInt(tree.get("width"));
        this.height = Integer.parseInt(tree.get("height"));
        //if (tree.get("fill").startsWith("image")) {
        //    this.image = tree.get("fill");
        //}
    }
   /* public TreeMap<String, Image> getrrImage() {
        Image img = null;
        String imgName = "resources/".concat(image);
        try {
            img = ImageIO.read(new File(imgName));
            blockImage.put(type, img);
            return blockImage;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }*/
}
