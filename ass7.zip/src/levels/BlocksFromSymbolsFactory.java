package levels;

import java.awt.Image;
import java.util.Map;
import java.util.TreeMap;

import sprites.Block;

/**
 *
 * @author gal.
 *
 */
public class BlocksFromSymbolsFactory {
    private Map<String, Integer> spacerWidths;
    private Map<String, BlockCreator> blockCreators;
    private Map<String, Integer> blocksWidths;
    private Map<String, Integer> blocksHeight;
    private TreeMap<String, Image> blockImage;
    /**
     *
     * @param spacerWidths a Map<String, Integer>
     * @param blockCreators a Map<String, BlockCreator>
     * @param blocksWidths a Map<String, Integer>
     * @param blocksheight a Map<String, Integer>
     * @param  blockImage a TreeMap<String, Image>
     */
    public BlocksFromSymbolsFactory(Map<String, Integer> spacerWidths, Map<String, BlockCreator> blockCreators,
            Map<String, Integer> blocksWidths, Map<String, Integer> blocksheight, TreeMap<String, Image> blockImage) {
        this.spacerWidths = spacerWidths;
        this.blockCreators = blockCreators;
        this.blocksWidths = blocksWidths;
        this.blocksHeight = blocksheight;
        this.blockImage = blockImage;
    }
    /**
     *
     * @param s String
     * @return true if 's' is a valid space symbol.
     */
    public boolean isSpaceSymbol(String s) {
        if (spacerWidths.containsKey(s)) {
            return true;
        }
        return false;
    }
    /**
     *
     * @param s String
     * @return true if 's' is a valid block symbol.
     */
    public boolean isBlockSymbol(String s) {
        if (blockCreators.containsKey(s)) {
            return true;
        }
        return false;
    }

    // Return a block according to the definitions associated
    // with symbol s. The block will be located at position (xpos, ypos).
    /**
     *
     * @param s a String
     * @param xpos an int
     * @param ypos an int
     * @return a Block
     */
    public Block getBlock(String s, int xpos, int ypos) {
        return this.blockCreators.get(s).create(xpos, ypos);
    }

    // Returns the width in pixels associated with the given spacer-symbol.
    /**
     *
     * @param s a String
     * @return an int
     */
    public int getSpaceWidth(String s) {
        //System.out.println(s);
        return this.spacerWidths.get(s);
    }
    /**
     *
     * @param s a String
     * @return an int
     */
    public int getWidth(String s) {
       return this.blocksWidths.get(s);
    }
    /**
    *
    * @param s a String
    * @return an int
    */
    public int getHeight(String s) {
        return this.blocksHeight.get(s);
     }
    /**
     *
     * @param s a String
     * @return an Image
     */
    public Image getImage(String s) {
        return this.blockImage.get(s);
     }
 }
