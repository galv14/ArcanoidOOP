package levels;

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import biuoop.DrawSurface;
import sprites.Sprite;
/**
 *
 * @author gal.
 *
 */
public class NewBackgruond implements Sprite {
    private String background;
    private Image img;
    /**
     *
     * @param background a String
     */
    public NewBackgruond(String background) {
        this.background = background;
        this.img = null;
        getImage();
    }
    @Override
    public void drawOn(DrawSurface d) {
        String name;
        if (this.img != null) {
           /* Image img = null;
            String r = "resources/";
            name = this.background.substring(6, this.background.length() - 1);
            try {
                img = ImageIO.read(new File(r.concat(name)));
            } catch (IOException e) {
                e.printStackTrace();
            }*/
            d.drawImage(0, 0, img);
        } else if (this.background.startsWith("color(RGB")) {
            String[] names = this.background.substring(10, this.background.length() - 2).split(",");
            Color color = new Color(Integer.parseInt(names[0]), Integer.parseInt(names[1]), Integer.parseInt(names[2]));
            d.setColor(color);
            d.fillRectangle(0, 0, 800, 600);
        } else {
            name = this.background.substring(6, this.background.length() - 1);
            try {
                Color aColor   = (Color) Color.class.getField(name).get(null);
                d.setColor(aColor);
                d.fillRectangle(0, 0, 800, 600);
            } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void timePassed(double dt) { }
    /**
     *
     */
    public void getImage() {
        String name;
        if (this.background.startsWith("image")) {
            String r = "resources/";
            name = this.background.substring(6, this.background.length() - 1);
            try {
                img = ImageIO.read(new File(r.concat(name)));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
