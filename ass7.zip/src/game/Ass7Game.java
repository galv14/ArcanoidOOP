package game;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import animation.Animation;
import animation.AnimationRunner;
import animation.HighScoresAnimation;
import animation.KeyPressStoppableAnimation;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import highscore.HighScoresTable;
import levels.LevelInformation;
import levels.LevelSpecificationReader;
import menu.ExitTask;
import menu.Menu;
import menu.MenuAnimation;
import menu.RunTask;
import menu.ShowHiScoresTask;
import menu.Task;

/**
 *
 * @author gal.
 *
 */
public class Ass7Game {
    public static final String TABLEKEY = "e";
    /**
     *
     * @param args user
     */
    public static void main(String[] args) {
        GUI gui = new GUI("Arkanoid", 800, 600);
        AnimationRunner ar = new AnimationRunner(gui);
        KeyboardSensor ks = gui.getKeyboardSensor();
        File highscores = new File("highScore");
        File file = new File("resources/definitions/level_definitions.txt");
        try {
            java.io.Reader reader = new InputStreamReader(new FileInputStream(file), "utf-8");
            LevelSpecificationReader x = new LevelSpecificationReader();
            while (true) {
                try {
                    List<LevelInformation> levels = x.fromReader(reader);
                    GameFlow flow = new GameFlow(ar, ks, gui, highscores);
                    HighScoresTable highScoreTable = HighScoresTable.loadFromFile(highscores);
                    Animation hSAnimation = new HighScoresAnimation(highScoreTable, TABLEKEY);
                    Menu<Task<Void>> menu = new MenuAnimation<Task<Void>>("arkanoid", ks);
                    menu.addSelection("s", "Press 's' to start a new game.", new RunTask(flow, levels));
                    menu.addSelection("h", "Press 'h' to see the high scores.",
                            new ShowHiScoresTask(ar, new KeyPressStoppableAnimation(ks, TABLEKEY, hSAnimation)));
                    menu.addSelection("q", "Press 'q' to quit.", new ExitTask(gui));
                    // wait for user selection
                    ar.run(menu);
                    Task<Void> task = menu.getStatus();
                    task.run();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        } catch (UnsupportedEncodingException | FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
