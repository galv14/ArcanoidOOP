package game;
import java.util.List;
import java.util.Random;

import animation.Animation;
import animation.AnimationRunner;
import animation.CountdownAnimation;
import animation.KeyPressStoppableAnimation;
import animation.PauseScreen;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import collision.Collidable;
import collision.GameEnvironment;
import levels.LevelInformation;
import listeners.BallRemover;
import listeners.BlockRemover;
import listeners.ScoreTrackingListener;
import listeners.ShieldRemover;
import shapes.Point;
import shapes.Rectangle;
import sprites.Block;
import sprites.LevelIndicator;
import sprites.LivesIndicator;
import sprites.Paddle;
import sprites.ScoreIndicator;
import sprites.Sprite;
import sprites.SpriteCollection;

/**
 *
 * @author gal.
 *
 */
public class GameLevel implements Animation {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int BLOCKWIDTH = 32;
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Counter blocksCounter;
    private Counter ballsCounter;
    private Counter score;
    private Counter livesCounter;
    private boolean running;
    private boolean hasTouch;
    private AnimationRunner runner;
    private Paddle p;
    private biuoop.KeyboardSensor keyboard;
    private LevelInformation level;
    private List<List<Block>> listB;
    //private List<List<Block>> again;
    private long startTime;
    private ScoreTrackingListener scoreListener;
    private int turnsWin;
    /**
     *
     * @param level a LevelInformation
     * @param keyboard a KeyboardSensor
     * @param runner an AnimationRunner
     * @param gui a GUI
     * @param score a Counter
     * @param livesCounter a Counter
     */
    public GameLevel(LevelInformation level, biuoop.KeyboardSensor keyboard, AnimationRunner runner,
            GUI gui, Counter score, Counter livesCounter) {
        this.environment = new GameEnvironment();
        this.sprites = new SpriteCollection();
        this.gui = gui;
        //this.gui = new GUI("Arkanoid", WIDTH, HEIGHT);
        this.blocksCounter = new Counter();
        this.ballsCounter = new Counter();
        this.score = score;
        this.livesCounter = livesCounter;
        this.runner = runner;
        this.keyboard = keyboard;
        //this.runner = new AnimationRunner(this.gui);
       // this.keyboard = this.gui.getKeyboardSensor();
        this.level = level;
        this.listB = level.blocks();
        //this.again = level.blocks();
        this.startTime = System.currentTimeMillis();
        this.hasTouch = false;
        this.turnsWin = 1;
    }
    /**
     *
     * @param c a Collidable
     */
   public void addCollidable(Collidable c) {
       this.environment.addCollidable(c);
   }
   /**
    *
    * @param c Collidable
    */
   public void removeCollidable(Collidable c) {
       this.environment.removeCollidable(c);
   }
   /**
    *
    * @param s a Sprite
    */
   public void addSprite(Sprite s) {
       this.sprites.addSprite(s);
   }
   /**
   *
   * @param s a Sprite
   */
  public void removeSprite(Sprite s) {
      this.sprites.removeSprite(s);
  }
  /**
   *
   * @return the counter
   */
  public Counter getBlocksCounter() {
      return this.blocksCounter;
  }
  /**
  *
  * @return the counter
  */
 public Counter getBallsCounter() {
     return this.ballsCounter;
 }
  /**
  *
  * @return the counter
  */
 public Counter getLivesCounter() {
     return this.livesCounter;
 }
 /**
  *
  * @return a boolean
  */
 public boolean getTouch() {
     return this.hasTouch;
 }
  @Override
  public boolean shouldStop() {
      return !this.running;
      }
  @Override
  public void doOneFrame(DrawSurface d, double dt) {
      Random rand = new Random();
      this.sprites.drawAllOn(d);
      if (blocksCounter.getValue() == 0) {
          //System.out.println(blocksCounter.getValue());
          this.turnsWin++;
          this.score.increase(100);
          this.listB = level.blocks();
          blocksInitialize(scoreListener);
          shieldsInitialize();
          this.p.removeFromGame(this);
          this.running = false;
      }
      if (this.listB.size() > 0) {
          int  n = rand.nextInt(this.listB.size());
          long usedTime = System.currentTimeMillis() - this.startTime;
          for (int i = 0; i < this.listB.size(); i++) {
              this.listB.get(i).get(this.listB.get(i).size() - 1).unSetCollumn();
              //System.out.println(this.listB.get(0).get(0).getCollisionRectangle().getUpperLeft().getX());
          }
          if (usedTime >= 500) {
              this.listB.get(n).get(this.listB.get(n).size() - 1).setCollumn();
              this.startTime = System.currentTimeMillis();
          }
          if (this.listB.get(this.listB.size() - 1).get(0).getCollisionRectangle().getUpperLeft().getX() > 760
                  || this.listB.get(0).get(0).getCollisionRectangle().getUpperLeft().getX() < 0) {
              // System.out.println("check");
               for (int i = 0; i < this.listB.size(); i++) {
                   for (int j = 0; j < this.listB.get(i).size(); j++) {
                       if (this.listB.get(i).get(j).getTouchShield()) {
                           this.hasTouch = true;
                           this.p.removeFromGame(this);
                           this.running = false;
                       } else {
                           double x = this.listB.get(i).get(j).getCollisionRectangle().getUpperLeft().getX()
                                   - this.listB.get(i).get(j).getSpeed() * this.listB.get(i).get(j).getDirection();
                           double y = this.listB.get(i).get(j).getCollisionRectangle().getUpperLeft().getY() + 20;
                           Point point = new Point(x, y);
                           this.listB.get(i).get(j).getCollisionRectangle().setUpperLeft(point);
                           this.listB.get(i).get(j).setDirection();
                           this.listB.get(i).get(j).setSpeed(this.turnsWin);
                       }
                   }
               }
               try {
                   Thread.sleep(50);
               } catch (InterruptedException e) {
                   // TODO Auto-generated catch block
                   e.printStackTrace();
               }
           }
      }
      if (this.p.getTouch()) {
          this.hasTouch = true;
          this.p.removeFromGame(this);
          this.running = false;
      }
      this.sprites.notifyAllTimePassed();
      if (this.keyboard.isPressed("p")) {
          this.runner.run(new KeyPressStoppableAnimation(this.keyboard, KeyboardSensor.SPACE_KEY, (new PauseScreen())));
      }
  }
   // Initialize a new game: create the Blocks and Ball (and Paddle)
   // and add them to the game.
   /**
    *
    */
   public void initialize() {
       this.addSprite(level.getBackground());
       this.scoreListener = new ScoreTrackingListener(this.score);
       ScoreIndicator showScore = new ScoreIndicator(this.score);
      // this.livesCounter.increase(114);
       LivesIndicator showLives = new LivesIndicator(this.livesCounter);
       LevelIndicator name = new LevelIndicator(this.level.levelName());
       frameInitialize();
       blocksInitialize(scoreListener);
       shieldsInitialize();
       this.addSprite(showScore);
       this.addSprite(showLives);
       this.addSprite(name);
   }
   /**
   *
   */
  public void paddleInitialize() {
      int place = 0;
      if (level.levelName() == "Wide Easy") {
          place = 120;
      } else {
          place = 360;
      }
      this.p = new Paddle(new Rectangle(place, HEIGHT - 40, this.level.paddleWidth(), 20),
              this.gui.getKeyboardSensor(), this.environment, this);
      this.p.setPaddleSpeed(this.level.paddleSpeed());
      this.p.getCollisionRectangle().setColor(java.awt.Color.ORANGE);
      this.p.addToGame(this);
  }
   /**
    *
    */
   public void frameInitialize() {
       BallRemover listen = new BallRemover(this);
       Block block = new Block(new Rectangle(-BLOCKWIDTH , 0, BLOCKWIDTH, HEIGHT));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block = new Block(new Rectangle(0, HEIGHT, WIDTH, BLOCKWIDTH));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this); // bottom
       block.addHitListener(listen);
       block = new Block(new Rectangle(WIDTH, 0, BLOCKWIDTH, HEIGHT));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block = new Block(new Rectangle(BLOCKWIDTH, BLOCKWIDTH, WIDTH - 2 * BLOCKWIDTH, BLOCKWIDTH));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       //block.addToGame(this);
       block = new Block(new Rectangle(0, 0, WIDTH, BLOCKWIDTH));
       block.getCollisionRectangle().setColor(java.awt.Color.LIGHT_GRAY);
       block.addToGame(this); //top
       block.addHitListener(listen);
   }
   /**
    * @param scoreListener1 a ScoreTrackingListener
    *
    */
   public void blocksInitialize(ScoreTrackingListener scoreListener1) {
       BallRemover ballListen = new BallRemover(this);
       BlockRemover listen = new BlockRemover(this, this.blocksCounter, this.listB);
       int i, j;
       for (j = 0; j < listB.size(); j++) {
           for (i = 0; i < listB.get(j).size(); i++) {
               listB.get(j).get(i).set(this.environment, this);
               listB.get(j).get(i).addToGame(this);
               listB.get(j).get(i).addHitListener(listen);
               listB.get(j).get(i).addHitListener(scoreListener1);
               listB.get(j).get(i).addHitListener(ballListen);
               if (this.turnsWin > 1) {
                   listB.get(j).get(i).setSpeed(this.turnsWin);
               }
           }
           //System.out.println(listB.size());
           listB.get(j).get(i - 1).setLast();
       }
       this.blocksCounter.increase(this.level.numberOfBlocksToRemove());
   }
   // Run the game -- start the animation loop.
   /**
    *
    */
   public void playOneTurn() {
       paddleInitialize();
       if (this.hasTouch) {
           this.hasTouch = false;
           returnBlocks();
           try {
               Thread.sleep(500);
           } catch (InterruptedException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
           }
       }
       //blocksInitialize(this.scoreListener);
       this.runner.run(new CountdownAnimation(2, 4, this.sprites));
       this.running = true;
       //this.hasTouch = false;
       this.runner.run(this);
   }
   /**
    *
    */
   public void returnBlocks() {
       for (int j = 0; j < listB.size(); j++) {
           for (int i = 0; i < listB.get(j).size(); i++) {
               Point point = new Point(25 + 55 * j, 50 + 40 * i);
               this.listB.get(j).get(i).getCollisionRectangle().setUpperLeft(point);
               this.listB.get(j).get(i).setPosDirection();
               this.listB.get(j).get(i).setUnTouchShield();
               this.listB.get(j).get(i).setReturnSpeed();
           }
       }
   }
   /**
    *
    */
   public void run() {
       while (this.livesCounter.getValue() > 0 && this.blocksCounter.getValue() > 0) {
           playOneTurn();
       }
       gui.close();
       return;
   }
   /**
    *
    */
   public void shieldsInitialize() {
       BallRemover ballListen = new BallRemover(this);
       ShieldRemover listen = new ShieldRemover(this);
       for (int t = 0; t < 3; t++) {
           for (int j = 0; j < 3; j++) {
               for (int i = 0; i < 20; i++) {
                   Block block = new Block(new Rectangle(80 + 6 * i + 250 * t, 500 + j * 5, 6, 5));
                   block.addToGame(this);
                   block.getCollisionRectangle().setColor(java.awt.Color.cyan);
                   block.addHitListener(listen);
                   block.addHitListener(ballListen);
               }
           }
       }
   }

}
