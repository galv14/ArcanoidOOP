package highscore;
/**
 *
 * @author gal.
 *
 */
public class ScoreInfo {
    private String name;
    private int score;
    /**
     *
     * @param name a String
     * @param score an int
     */
    public ScoreInfo(String name, int score) {
        this.name = name;
        this.score = score;
    }
    /**
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }
    /**
     *
     * @return the score
     */
    public int getScore() {
        return this.score;
    }
}
