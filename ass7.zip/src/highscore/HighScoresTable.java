package highscore;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author gal.
 *
 */
public class HighScoresTable {
    public static final int SIZE = 2;
    private int size;
    private int counter;
    private List<ScoreInfo> list;
    // Create an empty high-scores table with the specified size.
    // The size means that the table holds up to size top scores.
    /**
     *
     * @param size an int
     */
    public HighScoresTable(int size) {
        this.size = size;
        this.list = new ArrayList<ScoreInfo>();
        this.counter = 0;
        //ScoreInfo x = new ScoreInfo("", 0);
       // for (int i = 0; i < this.size; i++) {
         //   this.list.add(x);
       // }
    }

    // Add a high-score.
    /**
     *
     * @param score a ScoreInfo
     */
    public void add(ScoreInfo score) {
        if (counter < size) {
            this.list.add(score);
            this.counter++;
            if (this.counter > 1) {
                sort();
            }
        } else {
            if (getRank(score.getScore()) <= this.size) {
                this.list.remove(size - 1);
                this.list.add(score);
                if (this.counter > 1) {
                    sort();
                }
            }
        }
    }

    // Return table size.
    /**
     *
     * @return an int
     */
    public int size() {
        return this.size;
    }
    /**
     *
     * @return an int
     */
    public int getCounter() {
        return this.counter;
    }
    // Return the current high scores.
    // The list is sorted such that the highest
    // scores come first.
    /**
     *
     * @return a sorted List<ScoreInfo>
     */
    public List<ScoreInfo> getHighScores() {
        return this.list;
    }

    // return the rank of the current score: where will it
    // be on the list if added?
    // Rank 1 means the score will be highest on the list.
    // Rank `size` means the score will be lowest.
    // Rank > `size` means the score is too low and will not
    //      be added to the list.
    /**
     *
     * @param score an int
     * @return an int of the spot this score will be on the score board
     */
    public int getRank(int score) {
        int i;
        for (i = 0; i < this.counter; i++) {
            if (this.list.get(i).getScore() < score) {
                return i;
            }
        }
        return this.counter;
    }

    // Clears the table
    /**
     *
     */
    public void clear() {
        this.list.clear();
    }

    // Load table data from file.
    // Current table data is cleared.
    /**
     *
     * @param filename a File
     * @throws IOException exception
     */
    public void load(File filename) throws IOException {
        clear();
        ScoreInfo x;
        BufferedReader br = null;
        try {
            InputStreamReader reader = new InputStreamReader(new FileInputStream(filename), "utf-8");
            br = new BufferedReader(reader);
            String line = br.readLine();
            while (line != null) {
                String[] parts = line.split(": ");
                x = new ScoreInfo(parts[0], Integer.parseInt(parts[1]));
                add(x);
                line = br.readLine();
            }
        } catch (FileNotFoundException e) {
            System.err.println("Unable to find file: " + filename.getName());
        } catch (IOException e) {
            System.err.println("Failed reading file: " + filename.getName()
                    + ", message:" + e.getMessage());
            e.printStackTrace(System.err);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                System.err.println("Failed closing file: " + filename.getName());
            }
        }
    }

    // Save table data to the specified file.
    /**
     *
     * @param filename a File
     * @throws IOException exception
     */
    public void save(File filename) throws IOException {
        //InputStreamReader reader = new InputStreamReader(new FileInputStream(filename), "utf-8");
        //FileOutputStream fileOut = new FileOutputStream(filename);
       // ObjectOutputStream out = new ObjectOutputStream(fileOut);
       // for (i = 0; i < this.counter; i++) {
        //    out.writeObject(this.list.get(i));
      //  }
        //out.close();
        //fileOut.close();
        int i;
        PrintWriter writer = new PrintWriter(filename, "UTF-8");
        for (i = 0; i < this.counter; i++) {
            writer.print(this.list.get(i).getName() + ": ");
            writer.println(this.list.get(i).getScore());
        }
        writer.close();
    }

    // Read a table from file and return it.
    // If the file does not exist, or there is a problem with
    // reading it, an empty table is returned.
    /**
     *
     * @param filename a File
     * @return a HighScoresTable
     */
    public static HighScoresTable loadFromFile(File filename) {
        HighScoresTable table = new HighScoresTable(SIZE);
        if (!filename.exists()) {
            try {
                table.save(filename);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else {
            try {
                table.load(filename);
                } catch (Exception e) {
                    e.printStackTrace();
                }
           }
         return table;
    }
    /**
     *
     */
    public void sort() {
        int i, j;
        ScoreInfo temp;
       // System.out.println(counter);
        for (i = 0; i < this.counter; i++) {
            for (j = 0; j < this.counter - i - 1; j++) {
               // System.out.println(list.get(j).getScore());
               // System.out.println("bla" + j);
                if (list.get(j).getScore() < list.get(j + 1).getScore()) {
                    temp = list.get(j);
                    list.add(j, list.get(j + 1));
                    list.add(j + 1, temp);
                }
            }
        }
    }
    //public String toString() {
   // }
 }
