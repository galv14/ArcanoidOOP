package listeners;

import game.GameLevel;
import sprites.Ball;
import sprites.Block;

/**
 *
 * @author gal.
 *
 */
public class BallRemover implements HitListener {
    private GameLevel gameLevel;
   // private Counter remainingBalls;
    /**
     *
     * @param gameLevel a Game
     */
    public BallRemover(GameLevel gameLevel) {
        this.gameLevel = gameLevel;
       // this.remainingBalls = remainingBalls;
    }
    /**
    *
    * @param beingHit a Block
    * @param hitter a Ball
    *
    */
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(gameLevel);
        //remainingBalls.decrease(1);
    }

}
