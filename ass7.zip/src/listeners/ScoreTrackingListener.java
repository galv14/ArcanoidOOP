package listeners;
import game.Counter;
import sprites.Ball;
import sprites.Block;

/**
 *
 * @author gal.
 *
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;
    /**
     *
     * @param scoreCounter a Counter
     */
    public ScoreTrackingListener(Counter scoreCounter) {
       this.currentScore = scoreCounter;
    }
    /**
    *
    * @param beingHit a Block
    * @param hitter a Ball
    *
    */
    public void hitEvent(Block beingHit, Ball hitter) {
        if (!hitter.getAllien()) {
            this.currentScore.increase(100);
        }
    }
 }
