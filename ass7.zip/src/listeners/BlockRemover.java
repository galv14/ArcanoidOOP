package listeners;

import java.util.List;

import game.Counter;
import game.GameLevel;
import sprites.Ball;
import sprites.Block;

/**
 *
 * @author gal.
 *
 */
public class BlockRemover implements HitListener {
    private GameLevel gameLevel;
    private Counter remainingBlocks;
    private List<List<Block>> listB;
    private  int less;
    /**
     *
     * @param gameLevel a Game
     * @param removedBlocks a Counter
     * @param listB a List<List<Block>>
     */
    public BlockRemover(GameLevel gameLevel, Counter removedBlocks, List<List<Block>> listB) {
        this.gameLevel = gameLevel;
        this.remainingBlocks = removedBlocks;
        this.listB = listB;
        this.less = 0;
    }
    // Blocks that are hit and reach 0 hit-points should be removed
    // from the game. Remember to remove this listener from the block
    // that is being removed from the game.
    /**
     *
     * @param beingHit a Block
     * @param hitter a Ball
     *
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        //System.out.println("ffhfg");
       if (!hitter.getAllien()) {
           for (int i = 0; i < 10 - less; i++) {
              // System.out.println(less);
               if (this.listB.get(i).indexOf(beingHit) != -1) {
                   if (this.listB.get(i).indexOf(beingHit) == this.listB.get(i).size() - 1) {
                       beingHit.removeFromGame(gameLevel);
                       beingHit.removeHitListener(this);
                       remainingBlocks.decrease(1);
                       if (this.listB.get(i).indexOf(beingHit) > 0) {
                           this.listB.get(i).get(this.listB.get(i).indexOf(beingHit) - 1).setLast();
                       }
                       //System.out.println(this.listB.size());
                       //System.out.println("row  " + this.listB.get(i).indexOf(beingHit) + "     collumn  " + i);
                       if (this.listB.get(i).indexOf(beingHit) == 0) {
                           this.listB.remove(i);
                           this.less++;
                       } else if (this.listB.get(i).indexOf(beingHit) > 0) {
                           this.listB.get(i).remove(this.listB.get(i).indexOf(beingHit));
                       }

                   }
               }
           }
           /*
           for (int i = 0; i < 9; i++){
               if(this.listB.get(i).indexOf(beingHit) != -1) {
                   if (i >= 2) {
                       this.listB.get(i-2).get(this.listB.get(i).indexOf(beingHit)).setLast();
                      // System.out.println(this.listB.get(i).indexOf(beingHit)+ "     "+i);
                       //this.listB.get(i).remove(this.listB.get(i).indexOf(beingHit));
                   }
                  if (i==0) {
                      //this.listB.remove(i);
                      // System.out.println("dsgdfg");
                      // this.listB.remove(i);
                   }
                   //System.out.println(i);
                   System.out.println(this.listB.get(i).size());
               }
           }*/
           //if (beingHit.getHit().equalsIgnoreCase("1")) {
           //}
       }
    }
 }
