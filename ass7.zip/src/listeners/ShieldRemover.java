package listeners;

import game.GameLevel;
import sprites.Ball;
import sprites.Block;

/**
 *
 * @author gal.
 *
 */
public class ShieldRemover implements HitListener {
    private GameLevel gameLevel;
    /**
     *
     * @param gameLevel a GameLevel
     */
    public ShieldRemover(GameLevel gameLevel) {
        this.gameLevel = gameLevel;
    }
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        beingHit.removeFromGame(gameLevel);
        beingHit.removeHitListener(this);
    }

}
