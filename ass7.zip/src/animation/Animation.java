package animation;

import biuoop.DrawSurface;
/**
 *
 * @author gal
 *
 */
public interface Animation {
    /**
     *
     * @param d a DrawSurface
     * @param dt a double
     */
    void doOneFrame(DrawSurface d, double dt);
    /**
     *
     * @return whether the loop should stop or not
     */
    boolean shouldStop();
 }
