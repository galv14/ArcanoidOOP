package animation;

import biuoop.DrawSurface;
import game.Counter;
/**
 *
 * @author gal.
 *
 */
public class EndScreen implements Animation {
    private Counter score;
    /**
    *
    *
    * @param score a Counter
    * @param win a boolean
    *
    */
   public EndScreen(Counter score, boolean win) {
      //this.keyboard = k;
     // this.stop = false;
       //super(k, KeyboardSensor.SPACE_KEY, animation);
       this.score = score;
   }
    @Override
    public void doOneFrame(DrawSurface d, double dt) {
       // if (win) {
         //  d.drawText(10, d.getHeight() / 2, "You Win! Your score is " + Integer.toString(this.score.getValue()), 32);
       // } else {
            d.drawText(10, d.getHeight() / 2, "Game Over. Your score is "
        + Integer.toString(this.score.getValue()), 32);
       // }
        //super.doOneFrame(d, dt);
    }

    @Override
    public boolean shouldStop() { return true; }

}
