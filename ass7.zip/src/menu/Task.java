package menu;
/**
 *
 * @author gal
 *
 * @param <T>
 */
public interface Task<T> {
    /**
     *
     * @return T
     */
    T run();
 }
