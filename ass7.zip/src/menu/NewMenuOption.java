package menu;
/**
 *
 * @author gal
 *
 * @param <T> generic
 */
public class NewMenuOption<T> {
    private String key;
    private String message;
    private T returnVal;
    /**
     *
     * @param key a String
     * @param message a String
     * @param returnVal a T
     */
    public NewMenuOption(String key, String message, T returnVal) {
        this.key = key;
        this.message = message;
        this.returnVal = returnVal;
    }
    /**
     *
     * @return the key
     */
    public String getKey() {
        return this.key;
    }
    /**
     *
     * @return the message
     */
    public String getMessage() {
        return this.message;
    }
    /**
     *
     * @return the returnVal
     */
    public T getReturnVal() {
        return this.returnVal;
    }
}
