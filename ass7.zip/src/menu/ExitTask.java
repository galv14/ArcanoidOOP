package menu;

import biuoop.GUI;
/**
 *
 * @author gal.
 *
 */
public class ExitTask implements Task<Void> {
    private GUI gui;
    /**
     *
     * @param gui a GUI
     */
    public ExitTask(GUI gui) {
        this.gui = gui;
    }

    @Override
    public Void run() {
        gui.close();
        return null;
    }

}
