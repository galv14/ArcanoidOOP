package menu;

import java.util.ArrayList;
import java.util.List;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
/**
 *
 * @author gal.
 *
 * @param <T> generic
 */
public class MenuAnimation<T> implements Menu<T> {
    private String name;
    private KeyboardSensor keyboard;
    private boolean stop;
    private List<NewMenuOption<T>> list;
    private List<Menu<T>> menuList;
    private T status;
    /**
     *
     * @param name a String
     * @param keyboard a KeyboardSensor
     */
    public MenuAnimation(String name, KeyboardSensor keyboard) {
        this.stop = false;
        this.keyboard = keyboard;
        this.name = name;
        this.list = new ArrayList<NewMenuOption<T>>();
        this.status = null;
        this.menuList = new ArrayList<Menu<T>>();
       // this.nameStr = new TreeMap<Object, String>();
    }
    @Override
    public void doOneFrame(DrawSurface d, double dt) {
        d.drawText(200, 45, this.name, 50);
        for (int i = 0; i < this.list.size(); i++) {
            d.drawText(10, d.getHeight() / 4 + 25 * i, this.list.get(i).getMessage(), 25);
            if (this.keyboard.isPressed(this.list.get(i).getKey())) {
                this.status = this.list.get(i).getReturnVal();
                this.stop = true;
                }
        }
    }

    @Override
    public boolean shouldStop() {
        return this.stop;
    }
    @Override
    public T getStatus() {
        return this.status;
    }
    @Override
    public void addSelection(String key, String message, T returnVal) {
        NewMenuOption<T> x = new NewMenuOption<T>(key, message, returnVal);
        this.list.add(x);
    }
    @Override
    public void addSubMenu(String key, String message, Menu<T> subMenu) {
        this.menuList.add(subMenu);
       // addSelection(key, message, new KeyPressStoppableAnimation(this.keyboard, key, subMenu));
    }

}
