
import biuoop.GUI;
import biuoop.DrawSurface;

import java.util.Random;
import java.awt.Color;
/**
*
* @author gal eini
* 305216962
*
*/
public class AbstractArtDrawing {
    /**
     *
     */
  public void drawRandomCircles() {
    // Create a window with the title "Random Circles Example"
    // which is 400 pixels wide and 300 pixels high.
    GUI gui = new GUI("Random Circles Example", 400, 300);
    DrawSurface d = gui.getDrawSurface();
    int r = 3;
    int i;
    int j;
    Line [] line  = new Line[10];
    for (i = 0; i < 10; i++) {
       line[i] = generateRandomLine();
       d.drawLine((int) line[i].start().getX(), (int) line[i].start().getY(),
               (int) line[i].end().getX(), (int) line[i].end().getY());
       }
    for (i = 0; i < 10; i++) {
        d.setColor(Color.BLUE);
        d.fillCircle((int) line[i].middle().getX(), (int) line[i].middle().getY(), r);
    }
    for (i = 0; i < 10; i++) {
        for (j = 1 + i; j < 10; j++) {
            if (line[i].isIntersecting(line[j])) {
                d.setColor(Color.RED);
                d.fillCircle((int) line[i].intersectionWith(line[j]).getX(),
                        (int) line[i].intersectionWith(line[j]).getY(), r);
            }
        }
    }
    gui.show(d);
  }
  /**
   *
   * @param args user
   */
  public static void main(String[] args) {
      AbstractArtDrawing example = new AbstractArtDrawing();
     example.drawRandomCircles();
  }
  /**
   *
   * @return a random line
   */
  public Line generateRandomLine() {
      Random rand = new Random();
      int x1 = rand.nextInt(400) + 1; // get integer in range 1-400
      int y1 = rand.nextInt(300) + 1; // get integer in range 1-300
      int x2 = rand.nextInt(400) + 1; // get integer in range 1-400
      int y2 = rand.nextInt(300) + 1; // get integer in range 1-300
      Line line = new Line(x1, y1, x2, y2);
      return line;
  }
}
