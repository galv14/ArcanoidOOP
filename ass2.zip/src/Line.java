/**
 *
 * @author gal eini
 * 305216962
 *
 */

public class Line {
    private Point start;
    private Point end;
    private Point middle;
 // constructors
    /**
     *
     * @param start a point
     * @param end a point
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
        double midX = (start.getX() + end.getX()) / 2;
        double midY = (start.getY() + end.getY()) / 2;
        this.middle = new Point(midX, midY);
    }
    /**
     *
     * @param x1 x value
     * @param y1 y value
     * @param x2 x value
     * @param y2 y value
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
        double midX = (x1 + x2) / 2;
        double midY = (y1 + y2) / 2;
        this.middle = new Point(midX, midY);
    }

    // Return the length of the line
    /**
     *
     * @return the length of the liine
     */
    public double length() {
        return this.start.distance(end);
    }

    // Returns the middle point of the line
    /**
     *
     * @return the middle point of the line
     */
    public Point middle() {
        return this.middle;
    }

    // Returns the start point of the line
    /**
     *
     * @return the start point of the line
     */
    public Point start() {
        return this.start;
    }

    // Returns the end point of the line
    /**
     *
     * @return the end point of the line
     */
    public Point end() {
        return this.end;
    }
    /**
     *
     * @return the slope of the line
     */
    public double getSlope() {
        double thisSlope;
        double m = Double.POSITIVE_INFINITY;
       if (this.start.getX() - this.end.getX() != 0) {
            thisSlope = (this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX());
            return thisSlope;
        }
       return m;
    }

    // Returns true if the lines intersect, false otherwise
    /**
     *
     * @param other a line
     * @return true if the lines intersect, false otherwise
     */
    public boolean isIntersecting(Line other) {
        if (intersectionWith(other) != null) {
            return true;
        }
        return false;
    }

    // Returns the intersection point if the lines intersect,
    // and null otherwise.
    /**
     *
     * @param other a line
     * @return other Returns the intersection point if the lines intersect,
     * and null otherwise.
     */
    public Point intersectionWith(Line other) {
        double thisSlope;
        double otherSlope;
        double equationA;
        double equationB;
        double itrX;
        double itrY;
        Point intersact;
        thisSlope = getSlope();
        otherSlope = other.getSlope();
        if (thisSlope != otherSlope) {
            if (thisSlope == Double.POSITIVE_INFINITY) {
                equationA = this.start.getX();
                equationB = otherSlope * other.start.getX() - other.start.getY();
                itrX = (equationA - equationB) / (1 - otherSlope);
                itrY = (otherSlope * itrX) - equationB;
                intersact = new Point(itrX, itrY);
                return intersact;
            }
            if (otherSlope == Double.POSITIVE_INFINITY) {
                equationA = thisSlope * this.start.getX() - this.start.getY();
                equationB = other.start.getX();
                itrX = (equationA - equationB) / (thisSlope - 1);
                itrY = (thisSlope * itrX) - equationA;
                intersact = new Point(itrX, itrY);
                return intersact;
            }
            equationA = thisSlope * this.start.getX() - this.start.getY();
            equationB = otherSlope * other.start.getX() - other.start.getY();
            itrX = (equationA - equationB) / (thisSlope - otherSlope);
            itrY = (thisSlope * itrX) - equationA;
            intersact = new Point(itrX, itrY);
            if ((intersact.getX() <= this.start.getX() && intersact.getX() >= this.end.getX())
                    || (intersact.getX() >= this.start.getX() && intersact.getX() <= this.end.getX())) {
               if ((intersact.getX() <= other.start.getX() && intersact.getX() >= other.end.getX())
                        || (intersact.getX() >= other.start.getX() && intersact.getX() <= other.end.getX())) {
                    if ((intersact.getY() <= this.start.getY() && intersact.getY() >= this.end.getY())
                            || (intersact.getY() >= this.start.getY() && intersact.getY() <= this.end.getY())) {
                        if ((intersact.getY() <= other.start.getY() && intersact.getY() >= other.end.getY())
                                || (intersact.getY() >= other.start.getY() && intersact.getY() <= other.end.getY())) {
                            return intersact;
                        }
                    }
                }
            }
           return null;
        }
        if ((this.end.equals(other.start)) || (this.start.equals(other.start))) {
            if ((other.end.getX() >= this.end.getX() && other.end.getX() <= this.start.getX())
                    || (other.end.getX() <= this.end.getX() && other.end.getX() <= this.start.getX())) {
                if ((other.end.getY() >= this.end.getY() && other.end.getY() <= this.start.getY())
                        || (other.end.getY() <= this.end.getY() && other.end.getY() <= this.start.getY())) {
                    return null;
                }
            }
            return this.end;
        }
        if ((this.start.equals(other.end)) || (this.end.equals(other.end))) {
            if ((other.start.getX() >= this.end.getX() && other.start.getX() <= this.start.getX())
                    || (other.start.getX() <= this.end.getX() && other.start.getX() <= this.start.getX())) {
                if ((other.start.getY() >= this.end.getY() && other.start.getY() <= this.start.getY())
                        || (other.start.getY() <= this.end.getY() && other.start.getY() <= this.start.getY())) {
                    return null;
                }
            }
            return this.start;
        }
        return null;
    }

    // equals -- return true is the lines are equal, false otherwise
    /**
     *
     * @param other a line
     * @return true is the lines are equal, false otherwise
     */
    public boolean equals(Line other) {
        if (this.start.equals(other.start) && this.end.equals(other.end)) {
            return true;
        }
        if (this.start.equals(other.end) && this.end.equals(other.start)) {
            return true;
        }
        return false;
    }
}
