

import java.util.Random;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
*
* @author gal eini
* 305216962
*
*/
public class MultipleFramesBouncingBallsAnimation {
    /**
     *
     * @param args user
     */
    public static void main(String[] args) {
        //MultipleBouncingBallsAnimation.sort(args);
        Ball [] balls = new Ball[args.length - 1];
        randomCircles(balls, args);
        GUI gui = new GUI("title", 600, 600);
        Sleeper sleeper = new Sleeper();
        while (true) {
            DrawSurface d = gui.getDrawSurface();
            d.setColor(java.awt.Color.GRAY);
            d.fillRectangle(50, 50, 450, 450);
            d.setColor(java.awt.Color.YELLOW);
            d.fillRectangle(450, 450, 150, 150);
            for (int i = 0; i < balls.length; i++) {
                balls[i].moveOneStep();
                balls[i].drawOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(50);
        }
    }
    /**
     *
     * @param balls an array of Balls
     * @param args an array of Balls sizes
     */
    public static void randomCircles(Ball [] balls, String[] args) {
        Random rand = new Random();
        int x;
        int y;
        int r;
        int i;
        for (i = 0; i < balls.length / 2; i++) {
            for (int j = 0; j < args[i + 1].length(); j++) {
                if (args[i + 1].charAt(j) < '0' || args[i + 1].charAt(j) > '9') {
                    System.out.println("at least one of the balls's size is not correct");
                    System.exit(1);
                }
            }
            if (((int) Double.parseDouble(args[i + 1])) <= 0 || ((int) Double.parseDouble(args[i + 1])) > 450 / 2
                    || ((int) Double.parseDouble(args[i + 1])) > 450 / 2) {
                System.out.println("at least one of the balls's size is not correct");
                System.exit(1);
            }
            r =  (int) Double.parseDouble(args[i + 1]);
            x = rand.nextInt(500 - r) + 50 + r;
            y = rand.nextInt(500 - r) + 50 + r;
            balls[i] = new Ball(x, y, r, java.awt.Color.GREEN);
            balls[i].setBotR(500, 500);
            balls[i].setTopL(50, 50);
            MultipleBouncingBallsAnimation.ballVelocity(balls[i]);
        }
        for (i = balls.length / 2; i < balls.length; i++) {
            for (int j = 0; j < args[i + 1].length(); j++) {
                if (args[i + 1].charAt(j) < '0' || args[i + 1].charAt(j) > '9') {
                    System.out.println("at least one of the balls's size is not correct");
                    System.exit(1);
                }
            }
            if (((int) Double.parseDouble(args[i + 1])) <= 0 || ((int) Double.parseDouble(args[i + 1])) > 150 / 2
                    || ((int) Double.parseDouble(args[i + 1])) > 150 / 2) {
                System.out.println("at least one of the balls's size is not correct");
                System.exit(1);
            }
            r = Integer.parseInt(args[i + 1]);
            x = rand.nextInt(600 - r) + 450 + r;
            y = rand.nextInt(600 - r) + 450 + r;
            balls[i] = new Ball(x, y, r, java.awt.Color.GREEN);
            balls[i].setBotR(600, 600);
            balls[i].setTopL(450, 450);
            MultipleBouncingBallsAnimation.ballVelocity(balls[i]);
        }
    }
}
