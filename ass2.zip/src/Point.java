
/**
 *
 * @author gal eini
 * 305216962
 *
 */
public class Point {
    private double x;
    private double y;
    // constructor
    /**
     *
     * @param x value X
     * @param y value Y
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // distance -- return the distance of this point to the other point
    /**
     *
     * @param other a point
     * @return the distance between two points
     */
    public double distance(Point other) {
        double newX = (this.x - other.getX()) * (this.x - other.getX());
        double newY = (this.y - other.getY()) * (this.y - other.getY());
        return Math.sqrt(newX + newY);

    }

    // equals -- return true is the points are equal, false otherwise
    /**
     *
     * @param other a point
     * @return true is the points are equal, false otherwise
     */
    public boolean equals(Point other) {
        if (this.x == other.getX() && this.y == other.getY()) {
            return true;
        }
        return false;
    }

    // Return the x and y values of this point
    /**
     *
     * @return the x value
     */
    public double getX() {
        return this.x;
    }
    /**
     *
     * @param y1 the point y value
     */
    public void setY(double y1) {
         this.y = y1;
    }
    /**
     *
     * @param x1 the point x value
     */
    public void setX(double x1) {
        this.x = x1;
   }
    /**
     *
     * @return the y value
     */
    public double getY() {
        return this.y;
    }
 }
