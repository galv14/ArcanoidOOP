

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
*
* @author gal eini
* 305216962
*
*/
public class BouncingBallAnimation {
    /**
    *
    * @param args user
    */
    public static void main(String[] args) {
        Ball ball = new Ball(350, 50, 30, java.awt.Color.PINK);
        ball.setBotR(400, 400);
        ball.setTopL(0, 0);
        GUI gui = new GUI("title", (int) ball.getBotR().getX(), (int) ball.getBotR().getY());
        Sleeper sleeper = new Sleeper();
        Velocity v = Velocity.fromAngleAndSpeed(45, 19);
        ball.setVelocity(v);
       // ball.setVelocity(2, 1);
        while (true) {
           ball.moveOneStep();
           DrawSurface d = gui.getDrawSurface();
           ball.drawOn(d);
           gui.show(d);
           sleeper.sleepFor(100);  // wait for 50 milliseconds.
        }
    }

}
