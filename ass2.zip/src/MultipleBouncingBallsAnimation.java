
import java.util.Random;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
/**
*
* @author gal eini
* 305216962
*
*/
public class MultipleBouncingBallsAnimation {
    public static final int LENGTH = 1000;
    public static final int WIDTH = 500;
    public static final int ANGLE = 45;
    /**
     *
     * @param args user
     */
    public static void main(String[] args) {
        Ball [] balls = new Ball[args.length - 1];
        randomCircles(balls, args);
        GUI gui = new GUI("title", LENGTH, WIDTH);
        Sleeper sleeper = new Sleeper();
        while (true) {
            DrawSurface d = gui.getDrawSurface();
            for (int i = 0; i < balls.length; ++i) {
                balls[i].moveOneStep();
                balls[i].drawOn(d);
            }
                gui.show(d);
                sleeper.sleepFor(100);  // wait for 50 milliseconds.
        }
    }
    /**
     *
     * @param balls array of Ball
     * @param args sizes of the balls
     */
    public static void randomCircles(Ball [] balls, String[] args)  {
        Random rand = new Random();
        int x;
        int y;
        int r;
        for (int i = 0; i < balls.length; i++) {
            for (int j = 0; j < args[i + 1].length(); j++) {
                if (args[i + 1].charAt(j) < '0' || args[i + 1].charAt(j) > '9') {
                    System.out.println("at least one of the balls's size is not correct");
                    System.exit(1);
                }
            }
            if (((int) Double.parseDouble(args[i + 1])) <= 0 || ((int) Double.parseDouble(args[i + 1])) > LENGTH / 2
                    || ((int) Double.parseDouble(args[i + 1])) > WIDTH / 2) {
                System.out.println("at least one of the balls's size is not correct");
                System.exit(1);
            }
             r = (int) Double.parseDouble(args[i + 1]);
             x = rand.nextInt(LENGTH - r) + r;
             y = rand.nextInt(WIDTH - r) + r;
             balls[i] = new Ball(x, y, r, java.awt.Color.GREEN);
             balls[i].setBotR(LENGTH, WIDTH);
             balls[i].setTopL(0, 0);
             ballVelocity(balls[i]);
         }
    }
    /**
     *
     * @param balls a BallS
     */
    public static void ballVelocity(Ball balls) {
            int speed = 51;
            if (balls.getSize() >= 50) {
                speed = 1;
            } else {
                speed -= balls.getSize();
            }
            Velocity v = Velocity.fromAngleAndSpeed(ANGLE, speed);
            balls.setVelocity(v);
    }
}
