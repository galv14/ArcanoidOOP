
import biuoop.DrawSurface;
/**
*
* @author gal eini
* 305216962
*
*/
public class Ball {
    private Point center;
    private int r;
    private java.awt.Color color;
    private Velocity velocity;
    private Point botR;
    private Point topL;
    // constructor
    /**
     *
     * @param center value of the center
     * @param r value of the radius
     * @param color the color of the circle
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.velocity = new Velocity(0, 0);
    }
    /**
     *
     * @param x the x value of the center
     * @param y the y value of the center
     * @param r the value of the radius
     * @param color the color of the circle
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        this.r = r;
        this.color = color;
        this.velocity = new Velocity(0, 0);
    }
    // accessors
    /**
     *
     * @return the x value of the center
     */
    public int getX() {
        return (int) this.center.getX();
    }
    /**
     *
     * @return the y value of the center
     */
    public int getY() {
        return (int) this.center.getY();
    }
    /**
     *
     * @return the value of the radius
     */
    public int getSize() {
        return this.r;
    }
    /**
     *
     * @return the color of the circle
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    // draw the ball on the given DrawSurface
    /**
     *
     * @param surface the DrawSurface which will be drawn on
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.getColor());
        surface.fillCircle(this.getX(), this.getY(), this.r);
    }
    /**
     *
     * @param v the velocity of the ball
     */
    public void setVelocity(Velocity v) {
        this.velocity = v;
    }
    /**
     *
     * @param x the bottom right screen's x value
     * @param y the bottom right screen's x value
     */
    public void setBotR(double x, double y) {
        this.botR = new Point(x, y);
    }
    /**
     *
     * @param x the top left screen's x value
     * @param y the top left screen's x value
     */
    public void setTopL(double x, double y) {
        this.topL = new Point(x, y);
    }
    /**
     *
     * @return the size of the bottom right screen
     */
    public Point getBotR() {
        return this.botR;
    }
    /**
     *
     * @return the size of the top left screen
     */
    public Point getTopL() {
        return this.topL;
    }
    /**
     *
     * @param dx the x value of the velocity of the ball
     * @param dy the y value of the velocity of the ball
     */
    public void setVelocity(double dx, double dy) {
        this.velocity = new  Velocity(dx, dy);
    }
    /**
     *
     * @return the velocity of the ball
     */
    public Velocity getVelocity() {
        return this.velocity;
    }
    /**
     *
     */
    public void moveOneStep() {
          if (this.getVelocity().applyToPoint(this.center).getY() < this.botR.getY() - this.r
                  && this.getVelocity().applyToPoint(this.center).getY() > this.r + this.topL.getY()
                  && this.getVelocity().applyToPoint(this.center).getX() > this.r + this.topL.getY()
                  && this.getVelocity().applyToPoint(this.center).getX() < this.botR.getX() - this.r) {
              this.center = this.getVelocity().applyToPoint(this.center);
          }
          if (this.getVelocity().applyToPoint(this.center).getY() > this.botR.getY() - this.r) {
             this.center.setY(this.botR.getY() - this.r);
             setVelocity(this.getVelocity().getX(), -this.getVelocity().getY());
          }
          if (this.getVelocity().applyToPoint(this.center).getY() < this.r + this.topL.getY()) {
                 this.center.setY(this.r + this.topL.getY());
                 setVelocity(this.getVelocity().getX(), -this.getVelocity().getY());
          }
          if (this.getVelocity().applyToPoint(this.center).getX() < this.r + this.topL.getY()) {
              this.center.setX(this.r + this.topL.getY());
              setVelocity(-this.getVelocity().getX(), this.getVelocity().getY());
          }
          if (this.getVelocity().applyToPoint(this.center).getX() > this.botR.getX() - this.r) {
              this.center.setX(this.botR.getX() - this.r);
              setVelocity(-this.getVelocity().getX(), this.getVelocity().getY());
          }
    }
 }
