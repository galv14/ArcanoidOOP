package animation;
import biuoop.DrawSurface;
import sprites.SpriteCollection;

/**
 *
 * @author gal.
 *
 */
public class CountdownAnimation implements Animation {
    private double numOfSeconds;
    private int countFrom;
    private int display;
    private SpriteCollection gameScreen;
    private boolean stop;
    /**
     *
     * @param numOfSeconds a double
     * @param countFrom an int
     * @param gameScreen a SpriteCollection
     */
    public CountdownAnimation(double numOfSeconds, int countFrom, SpriteCollection gameScreen) {
        this.numOfSeconds = numOfSeconds;
        this.countFrom = countFrom;
        this.display = countFrom;
        this.gameScreen = gameScreen;
    }
    @Override
    public void doOneFrame(DrawSurface d) {
        this.gameScreen.drawAllOn(d);
        double x;
        d.setColor(java.awt.Color.YELLOW);
        d.drawText(d.getWidth() / 2, d.getHeight() / 3, Integer.toString(countFrom), 100);
        countFrom--;
            x = (numOfSeconds / display) * 1000;
        try {
            Thread.sleep((long) (x));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (this.countFrom == -1) {
            this.stop = true;
        }
    }
    @Override
    public boolean shouldStop() { return this.stop; }

}
