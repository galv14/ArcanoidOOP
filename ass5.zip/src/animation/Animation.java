package animation;

import biuoop.DrawSurface;
/**
 *
 * @author gal
 *
 */
public interface Animation {
    /**
     *
     * @param d a DrawSurface
     */
    void doOneFrame(DrawSurface d);
    /**
     *
     * @return whether the loop should stop or not
     */
    boolean shouldStop();
 }
