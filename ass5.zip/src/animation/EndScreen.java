package animation;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import game.Counter;
/**
 *
 * @author gal.
 *
 */
public class EndScreen implements Animation {
    private KeyboardSensor keyboard;
    private boolean stop;
    private Counter score;
    /**
    *
    * @param k a KeyboardSensor
    * @param score a Counter
    */
   public EndScreen(KeyboardSensor k, Counter score) {
      this.keyboard = k;
      this.stop = false;
      this.score = score;
   }
    @Override
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2, "Game Over. Your score is " + Integer.toString(this.score.getValue()), 32);
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) { this.stop = true; }
    }

    @Override
    public boolean shouldStop() { return this.stop; }

}
