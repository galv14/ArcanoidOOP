package game;

import java.util.ArrayList;
import java.util.List;

import animation.AnimationRunner;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import levels.DirectHit;
import levels.FinalFour;
import levels.Green3;
import levels.LevelInformation;
import levels.WideEasy;

/**
 *
 * @author gal.
 *
 */
public class Ass5Game {
    /**
     *
     * @param args user
     */
    public static void main(String[] args) {
        GUI gui = new GUI("Arkanoid", 800, 600);
        AnimationRunner ar = new AnimationRunner(gui);
        KeyboardSensor ks = gui.getKeyboardSensor();
        List<LevelInformation> levels = new ArrayList<LevelInformation>();
        for (int i = 1; i < args.length; i++) {
            if (args[i].equals("1")) {
                DirectHit lev1 = new DirectHit();
                levels.add(lev1);
            }
            if (args[i].equals("2")) {
                WideEasy lev2 = new WideEasy();
                levels.add(lev2);
            }
            if (args[i].equals("3")) {
                Green3 lev3 = new Green3();
                levels.add(lev3);
            }
            if (args[i].equals("4")) {
                FinalFour lev4 = new FinalFour();
                levels.add(lev4);
            }
        }
        if (levels.isEmpty()) {
            DirectHit lev1 = new DirectHit();
            WideEasy lev2 = new WideEasy();
            Green3 lev3 = new Green3();
            FinalFour lev4 = new FinalFour();
            levels.add(lev1);
            levels.add(lev2);
            levels.add(lev3);
            levels.add(lev4);
        }
        GameFlow flow = new GameFlow(ar, ks, gui);
        flow.runLevels(levels);
        //GameLevel gameLevel = new GameLevel(lev4);
        //gameLevel.initialize();
       // gameLevel.run();
     }
}
