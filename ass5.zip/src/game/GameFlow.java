package game;

import java.util.List;

import animation.AnimationRunner;
import animation.EndScreen;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import levels.LevelInformation;
/**
 *
 * @author gal.
 *
 */
public class GameFlow {
    private AnimationRunner animationRunner;
    private KeyboardSensor keyboardSensor;
    private GUI gui;
    /**
     *
     * @param ar an AnimationRunner
     * @param ks a KeyboardSensor
     * @param gui a GUI
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, GUI gui) {
        this.animationRunner = ar;
        this.keyboardSensor = ks;
        this.gui = gui;
    }
    /**
     *
     * @param levels a List<LevelInformation>
     */
    public void runLevels(List<LevelInformation> levels) {
        Counter score = new Counter();
        Counter lives = new Counter();
        lives.increase(7);
       for (LevelInformation levelInfo : levels) {

          GameLevel level = new GameLevel(levelInfo,
                this.keyboardSensor,
                this.animationRunner, this.gui, score, lives);

          level.initialize();

          while (level.getBlocksCounter().getValue() > 0 && level.getLivesCounter().getValue() > 0) {
             level.playOneTurn();
             if (level.getBallsCounter().getValue() == 0) {
                 lives.decrease(1);
             }
          }
          if (level.getLivesCounter().getValue() == 0) {
             break;
         }
       }
       this.animationRunner.run(new EndScreen(this.keyboardSensor, score));
       gui.close();
    }
 }
