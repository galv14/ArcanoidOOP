package game;
/**
 *
 * @author gal.
 *
 */
public class Counter {
    private int count;
    /**
     *
     */
    public Counter() {
        this.count = 0;
    }
    // add number to current count.
    /**
     *
     * @param number an int
     */
    public void increase(int number) {
        this.count += number;
    }
    // subtract number from current count.
    /**
    *
    * @param number an int
    */
    public void decrease(int number) {
        this.count -= number;
    }
    // get current count.
    /**
     *
     * @return an int
     */
    public int getValue() {
        return this.count;
    }
 }
