package game;
import java.util.List;

import animation.Animation;
import animation.AnimationRunner;
import animation.CountdownAnimation;
import animation.PauseScreen;
import biuoop.DrawSurface;
import biuoop.GUI;
import collision.Collidable;
import collision.GameEnvironment;
import levels.LevelInformation;
import listeners.BallRemover;
import listeners.BlockRemover;
import listeners.ScoreTrackingListener;
import shapes.Rectangle;
import sprites.Ball;
import sprites.Block;
import sprites.LevelIndicator;
import sprites.LivesIndicator;
import sprites.Paddle;
import sprites.ScoreIndicator;
import sprites.Sprite;
import sprites.SpriteCollection;
import sprites.Velocity;

/**
 *
 * @author gal.
 *
 */
public class GameLevel implements Animation {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int BLOCKWIDTH = 32;
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Counter blocksCounter;
    private Counter ballsCounter;
    private Counter score;
    private Counter livesCounter;
    private boolean running;
    private AnimationRunner runner;
    private Paddle p;
    private biuoop.KeyboardSensor keyboard;
    private LevelInformation level;
    /**
     *
     * @param level a LevelInformation
     * @param keyboard a KeyboardSensor
     * @param runner an AnimationRunner
     * @param gui a GUI
     * @param score a Counter
     * @param livesCounter a Counter
     */
    public GameLevel(LevelInformation level, biuoop.KeyboardSensor keyboard, AnimationRunner runner,
            GUI gui, Counter score, Counter livesCounter) {
        this.environment = new GameEnvironment();
        this.sprites = new SpriteCollection();
        this.gui = gui;
        //this.gui = new GUI("Arkanoid", WIDTH, HEIGHT);
        this.blocksCounter = new Counter();
        this.ballsCounter = new Counter();
        this.score = score;
        this.livesCounter = livesCounter;
        this.runner = runner;
        this.keyboard = keyboard;
        //this.runner = new AnimationRunner(this.gui);
       // this.keyboard = this.gui.getKeyboardSensor();
        this.level = level;
    }
    /**
     *
     * @param c a Collidable
     */
   public void addCollidable(Collidable c) {
       this.environment.addCollidable(c);
   }
   /**
    *
    * @param c Collidable
    */
   public void removeCollidable(Collidable c) {
       this.environment.removeCollidable(c);
   }
   /**
    *
    * @param s a Sprite
    */
   public void addSprite(Sprite s) {
       this.sprites.addSprite(s);
   }
   /**
   *
   * @param s a Sprite
   */
  public void removeSprite(Sprite s) {
      this.sprites.removeSprite(s);
  }
  /**
   *
   * @return the counter
   */
  public Counter getBlocksCounter() {
      return this.blocksCounter;
  }
  /**
  *
  * @return the counter
  */
 public Counter getBallsCounter() {
     return this.ballsCounter;
 }
  /**
  *
  * @return the counter
  */
 public Counter getLivesCounter() {
     return this.livesCounter;
 }
  @Override
  public boolean shouldStop() {
      return !this.running;
      }
  @Override
  public void doOneFrame(DrawSurface d) {
      this.sprites.drawAllOn(d);
    //  d.setColor(java.awt.Color.BLACK);
      //d.drawText(200, 22, this.level.levelName(), 100);
      if (blocksCounter.getValue() == 0 || ballsCounter.getValue() == 0) {
          if (blocksCounter.getValue() == 0) {
              this.score.increase(100);
          }
          this.p.removeFromGame(this);
          this.running = false;
      }
      this.sprites.notifyAllTimePassed();
      if (this.keyboard.isPressed("p")) {
          this.runner.run(new PauseScreen(this.keyboard));
      }
  }
   // Initialize a new game: create the Blocks and Ball (and Paddle)
   // and add them to the game.
   /**
    *
    */
   public void initialize() {
       this.addSprite(level.getBackground());
       BlockRemover listen = new BlockRemover(this, this.blocksCounter);
       ScoreTrackingListener scoreListener = new ScoreTrackingListener(this.score);
       ScoreIndicator showScore = new ScoreIndicator(this.score);
      // this.livesCounter.increase(114);
       LivesIndicator showLives = new LivesIndicator(this.livesCounter);
       LevelIndicator name = new LevelIndicator(this.level.levelName());
       frameInitialize();
       blocksInitialize(listen, scoreListener);
       this.addSprite(showScore);
       this.addSprite(showLives);
       this.addSprite(name);
   }
   /**
   *
   */
  public void paddleInitialize() {
      int place = 0;
      if (level.levelName() == "Wide Easy") {
          place = 120;
      } else {
          place = 360;
      }
      this.p = new Paddle(new Rectangle(place, HEIGHT - 50, this.level.paddleWidth(), 20),
              this.gui.getKeyboardSensor());
      this.p.setPaddleSpeed(this.level.paddleSpeed());
      this.p.getCollisionRectangle().setColor(java.awt.Color.ORANGE);
      this.p.addToGame(this);
  }
   /**
    *
    *
    */
   public void ballsInitialize() {
       int i;
       //System.out.println(level.numberOfBalls());
       for (i = 0; i < level.numberOfBalls(); i++) {
           Ball ball = new Ball(410, 540, 5, java.awt.Color.WHITE);
          // Ball ball = new Ball(340, 580, 5, java.awt.Color.WHITE);
           ball.setGameEnvironment(this.environment);
           Velocity v = level.initialBallVelocities().get(i);
           ball.setVelocity(v);
           ball.addToGame(this);
       }
       this.ballsCounter.increase(level.numberOfBalls());
   }
   /**
    *
    */
   public void frameInitialize() {
       BallRemover listen = new BallRemover(this, this.ballsCounter);
       Block block = new Block(new Rectangle(0, 0, BLOCKWIDTH, HEIGHT));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block = new Block(new Rectangle(BLOCKWIDTH, HEIGHT, 1270, BLOCKWIDTH));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block.addHitListener(listen);
       block = new Block(new Rectangle(WIDTH - BLOCKWIDTH, 0, BLOCKWIDTH, HEIGHT));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block = new Block(new Rectangle(BLOCKWIDTH, BLOCKWIDTH, WIDTH - 2 * BLOCKWIDTH, BLOCKWIDTH));
       block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
       block.addToGame(this);
       block = new Block(new Rectangle(0, 0, WIDTH, BLOCKWIDTH));
       block.getCollisionRectangle().setColor(java.awt.Color.LIGHT_GRAY);
       block.addToGame(this);
   }
   /**
    * @param scoreListener a ScoreTrackingListener
    * @param listen a PrintingHitListener
    *
    */
   public void blocksInitialize(BlockRemover listen, ScoreTrackingListener scoreListener) {
       List<Block> listB;
       listB = level.blocks();
       int i;
       for (i = 0; i < listB.size(); i++) {
           //listB.get(i).getCollisionRectangle().setColor(java.awt.Color.RED);
           //listB.get(i).setHit(1);
           listB.get(i).addToGame(this);
           listB.get(i).addHitListener(listen);
           listB.get(i).addHitListener(scoreListener);
       }
       this.blocksCounter.increase(this.level.numberOfBlocksToRemove());
       //blocksInitialize1(listen, scoreListener);
       //blocksInitialize2(listen, scoreListener);
      //blocksInitialize3(listen, scoreListener);
      //blocksInitialize4(listen, scoreListener);
       //blocksInitialize5(listen, scoreListener);
      //blocksInitialize6(listen, scoreListener);
   }
   /**
   *
   * @param scoreListener a ScoreTrackingListener
   * @param listen a PrintingHitListener
   *
   */
   public void blocksInitialize1(BlockRemover listen, ScoreTrackingListener scoreListener) {
       int count = 50;
       Block block = null;
       int i;
       for (i = 0; i < 12; i++) {
           block = new Block(new Rectangle(WIDTH - BLOCKWIDTH - ((i + 1) * count), 150, count, BLOCKWIDTH));
           block.getCollisionRectangle().setColor(java.awt.Color.PINK);
           block.setHit(2);
           block.addToGame(this);
           block.addHitListener(listen);
           block.addHitListener(scoreListener);
       }
       this.blocksCounter.increase(i);
   }
   /**
   *
   * @param scoreListener a ScoreTrackingListener
   * @param listen a PrintingHitListener
   *
   */
   public void blocksInitialize2(BlockRemover listen, ScoreTrackingListener scoreListener) {
       int count = 50;
       Block block = null;
       int i;
       for (i = 0; i < 11; i++) {
           block = new Block(new Rectangle(WIDTH - BLOCKWIDTH - ((i + 1) * count), 180, count, BLOCKWIDTH));
           block.getCollisionRectangle().setColor(java.awt.Color.BLUE);
           block.setHit(1);
           block.addToGame(this);
           block.addHitListener(listen);
           block.addHitListener(scoreListener);
       }
       this.blocksCounter.increase(i);
   }
   /**
   *
   * @param scoreListener a ScoreTrackingListener
   * @param listen a PrintingHitListener
   *
   */
   public void blocksInitialize3(BlockRemover listen, ScoreTrackingListener scoreListener) {
       int count = 50;
       Block block = null;
       int i;
       for (i = 0; i < 10; i++) {
           block = new Block(new Rectangle(WIDTH - BLOCKWIDTH - ((i + 1) * count), 210, count, BLOCKWIDTH));
           block.getCollisionRectangle().setColor(java.awt.Color.RED);
           block.setHit(1);
           block.addToGame(this);
           block.addHitListener(listen);
           block.addHitListener(scoreListener);
       }
       this.blocksCounter.increase(i);
   }
   /**
   *
   * @param scoreListener a ScoreTrackingListener
   * @param listen a PrintingHitListener
   *
   */
   public void blocksInitialize4(BlockRemover listen, ScoreTrackingListener scoreListener) {
       int count = 50;
       Block block = null;
       int i;
       for (i = 0; i < 9; i++) {
           block = new Block(new Rectangle(WIDTH - BLOCKWIDTH - ((i + 1) * count), 240, count, BLOCKWIDTH));
           block.getCollisionRectangle().setColor(java.awt.Color.GREEN);
           block.setHit(1);
           block.addToGame(this);
           block.addHitListener(listen);
           block.addHitListener(scoreListener);
       }
       this.blocksCounter.increase(i);
   }
   /**
   *
   * @param scoreListener a ScoreTrackingListener
   * @param listen a PrintingHitListener
   *
   */
   public void blocksInitialize5(BlockRemover listen, ScoreTrackingListener scoreListener) {
       int count = 50;
       Block block = null;
       int i;
       for (i = 0; i < 8; i++) {
           block = new Block(new Rectangle(WIDTH - BLOCKWIDTH - ((i + 1) * count), 270, count, BLOCKWIDTH));
           block.getCollisionRectangle().setColor(java.awt.Color.YELLOW);
           block.setHit(1);
           block.addToGame(this);
           block.addHitListener(listen);
           block.addHitListener(scoreListener);
       }
       this.blocksCounter.increase(i);
   }
   /**
   *
   * @param scoreListener a ScoreTrackingListener
   * @param listen a PrintingHitListener
   *
   */
   public void blocksInitialize6(BlockRemover listen, ScoreTrackingListener scoreListener) {
       int count = 50;
       Block block = null;
       int i;
       for (i = 0; i < 7; i++) {
           block = new Block(new Rectangle(WIDTH - BLOCKWIDTH - ((i + 1) * count), 300, count, BLOCKWIDTH));
           block.getCollisionRectangle().setColor(java.awt.Color.ORANGE);
           block.setHit(1);
           block.addToGame(this);
           block.addHitListener(listen);
           block.addHitListener(scoreListener);
       }
       this.blocksCounter.increase(i);
       //System.out.println(counter.getValue());
   }
   // Run the game -- start the animation loop.
   /**
    *
    */

   public void playOneTurn() {
       paddleInitialize();
       ballsInitialize();
       //ballsInitialize(450, 500);
       this.runner.run(new CountdownAnimation(2, 4, this.sprites));
       this.running = true;
       this.runner.run(this);
   }
   /**
    *
    */
   public void run() {
       while (this.livesCounter.getValue() > 0 && this.blocksCounter.getValue() > 0) {
           playOneTurn();
           //this.livesCounter.decrease(1);
       }
       gui.close();
       return;
   }

}
