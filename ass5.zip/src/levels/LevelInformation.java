package levels;

import java.util.List;
import sprites.Block;
import sprites.Sprite;
import sprites.Velocity;
/**
 *
 * @author gal.
 *
 */
public interface LevelInformation {
    /**
     *
     * @return an int of the number Of Balls
     */
    int numberOfBalls();
    // The initial velocity of each ball
    // Note that initialBallVelocities().size() == numberOfBalls()
    /**
     *
     * @return a List of Velocity's
     */
    List<Velocity> initialBallVelocities();
    /**
     *
     * @return an int of the paddle Speed
     */
    int paddleSpeed();
    /**
     *
     * @return an int of the paddle Width
     */
    int paddleWidth();
    // the level name will be displayed at the top of the screen.
    /**
     *
     * @return a String of the level Name
     */
    String levelName();
    // Returns a sprite with the background of the level
    /**
     *
     * @return a sprite with the background of the level
     */
    Sprite getBackground();
    // The Blocks that make up this level, each block contains
    // its size, color and location.
    /**
     *
     * @return The Blocks that make up this level
     */
    List<Block> blocks();
    // Number of levels that should be removed
    // before the level is considered to be "cleared".
    // This number should be <= blocks.size();
    /**
     *
     * @return the Number of blocks that should be removed before the level is considered to be "cleared".
     */
    int numberOfBlocksToRemove();
 }
