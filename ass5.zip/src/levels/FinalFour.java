package levels;

import java.util.ArrayList;
import java.util.List;

import shapes.Rectangle;
import sprites.Backgruond4;
import sprites.Block;
import sprites.Sprite;
import sprites.Velocity;
/**
 *
 * @author gal.
 *
 */
public class FinalFour implements LevelInformation {
    private List<Velocity> listV;
    private List<Block> listB;
    /**
     *
     */
    public FinalFour() {
        this.listV = new ArrayList<Velocity>();
        this.listB = new ArrayList<Block>();
    }

    @Override
    public int numberOfBalls() {
        return 3;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        Velocity v;
        v = Velocity.fromAngleAndSpeed(315, 6);
        this.listV.add(v);
        v = Velocity.fromAngleAndSpeed(0, 6);
        this.listV.add(v);
        v = Velocity.fromAngleAndSpeed(45, 6);
        this.listV.add(v);
        return listV;
    }

    @Override
    public int paddleSpeed() {
        return 8;
    }

    @Override
    public int paddleWidth() {
        return 100;
    }

    @Override
    public String levelName() {
        return "Final Four";
    }

    @Override
    public Sprite getBackground() {
        Backgruond4 x = new Backgruond4();
        return x;
    }

    @Override
    public List<Block> blocks() {
        int i, j;
        Block block = null;
        for (j = 0; j < 7; j++) {
            for (i = 0; i < 15; i++) {
                block = new Block(new Rectangle(32 + 49 * i, 120 + j * 32, 49, 32));
                switch(j) {
                case 0:
                    block.getCollisionRectangle().setColor(java.awt.Color.GRAY);
                    block.setHit(2);
                    this.listB.add(block);
                    break;
                case 1:
                    block.getCollisionRectangle().setColor(java.awt.Color.RED);
                    block.setHit(1);
                    this.listB.add(block);
                    break;
                case 2:
                    block.getCollisionRectangle().setColor(java.awt.Color.YELLOW);
                    block.setHit(1);
                    this.listB.add(block);
                    break;
                case 3:
                    block.getCollisionRectangle().setColor(java.awt.Color.GREEN);
                    block.setHit(1);
                    this.listB.add(block);
                    break;
                case 4:
                    block.getCollisionRectangle().setColor(java.awt.Color.WHITE);
                    block.setHit(1);
                    this.listB.add(block);
                    break;
                case 5:
                    block.getCollisionRectangle().setColor(java.awt.Color.PINK);
                    block.setHit(1);
                    this.listB.add(block);
                    break;
                default:
                    block.getCollisionRectangle().setColor(java.awt.Color.cyan);
                    block.setHit(1);
                    this.listB.add(block);
                    break;
                }
               // block.getCollisionRectangle().setColor(java.awt.Color.cyan);
               // block.setHit(1);
                //this.listB.add(block);
            }
        }
        return listB;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return 105;
    }

}

