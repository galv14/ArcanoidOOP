package sprites;

import biuoop.DrawSurface;
import game.Counter;
import game.GameLevel;
/**
 *
 * @author gal.
 *
 */
public class LivesIndicator implements Sprite {
    private Counter lives;
    /**
    *
    * @param livesCounter a Counter
    */
   public LivesIndicator(Counter livesCounter) {
       this.lives = livesCounter;
   }

    @Override
    public void drawOn(DrawSurface d) {
        d.drawText(200, 22, "lives: " + Integer.toString(this.lives.getValue()), 25);
    }
    @Override
    public void timePassed() {
    }
    /**
    *
    * @param g a Game
    */
   public void addToGame(GameLevel g) {
       g.addSprite(this);
   }
}
