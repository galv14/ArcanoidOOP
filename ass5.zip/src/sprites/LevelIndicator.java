package sprites;

import biuoop.DrawSurface;
import game.GameLevel;
/**
 *
 * @author gal.
 *
 */
public class LevelIndicator implements Sprite {
    private String name;
    /**
     *
     * @param s a String of the level's name
     */
    public LevelIndicator(String s) {
        this.name = s;
    }

    @Override
    public void drawOn(DrawSurface d) {
        d.drawText(600, 22, this.name, 25);
    }

    @Override
    public void timePassed() {
    }
    /**
    *
    * @param g a Game
    */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

}
