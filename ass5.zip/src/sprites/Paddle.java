package sprites;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import collision.Collidable;
import game.GameLevel;
import shapes.Line;
import shapes.Point;
import shapes.Rectangle;

/**
 *
 * @author gal.
 *
 */
public class Paddle implements Collidable, Sprite {
   private biuoop.KeyboardSensor keyboard;
   private Rectangle rect;
   private double length;
   @SuppressWarnings("unused")
   private boolean hit1;
   private int pSpeed;
 //  private GameEnvironment game1;
   /**
    *
    * @param rect a Rectangle
    * @param keyboard2 a GUI
    */
   public Paddle(Rectangle rect, KeyboardSensor keyboard2) {
       this.rect = rect;
       this.length = rect.getWidth() / 5;
       this.hit1 = false;
       this.keyboard = keyboard2;
       this.pSpeed = 0;
   }
   /**
    *
    */
   public void moveLeft() {
       if (this.rect.getUpperLeft().getX() - pSpeed > 32) {
           Point x = new Point(this.rect.getUpperLeft().getX() - pSpeed, this.rect.getUpperLeft().getY());
           this.rect.setUpperLeft(x);
       } else {
           Point x = new Point(32, this.rect.getUpperLeft().getY());
           this.rect.setUpperLeft(x);
       }
   }
   /**
    *
    */
   public void moveRight() {
       if (this.rect.getUpperLeft().getX()  + pSpeed < 768 - getLength()) {
           Point x = new Point(this.rect.getUpperLeft().getX() + pSpeed, this.rect.getUpperLeft().getY());
           this.rect.setUpperLeft(x);
       } else {
           Point x = new Point(768 - getLength(), this.rect.getUpperLeft().getY());
           this.rect.setUpperLeft(x);
       }
   }
   /**
    *
    * @return the length pf the paddle
    */
   public double getLength() {
       return this.rect.getUp().length();
   }
   /**
    *
    * @param x an int
    */
   public void setPaddleSpeed(int x) {
       this.pSpeed = x;
   }
   // Sprite
   /**
    *
    */
   public void timePassed() {
       if (this.keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
          moveLeft();
       }
       if (this.keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
           moveRight();
       }
   }
   /**
    * @param d a DrawSurface
    */
   public void drawOn(DrawSurface d) {
       d.setColor(this.rect.getColor());
       d.fillRectangle((int) this.rect.getUpperLeft().getX(), (int) this.rect.getUpperLeft().getY(),
               (int) this.rect.getWidth(), (int) this.rect.getHeight());
       d.setColor(java.awt.Color.BLACK);
       d.drawRectangle((int) this.rect.getUpperLeft().getX(), (int) this.rect.getUpperLeft().getY(),
               (int) this.rect.getWidth(), (int) this.rect.getHeight());
   }

   // Collidable
   /**
    *
    * @return a Rectangle
    */
   public Rectangle getCollisionRectangle() {
       return this.rect;
   }
   /**
   *
   * @param hitter a Ball
   * @param collisionPoint a Point
   * @param currentVelocity a Velocity
   * @return a new velocity after the hit
   */
   public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
       this.hit1 = true;
       double angle;
       double speed;
       Line line1 = new Line(rect.getUpperLeft().getX(), rect.getUpperLeft().getY(),
               rect.getUpperLeft().getX() + 0.1 + this.length, rect.getUpperLeft().getY());
       Line line2 = new Line(rect.getUpperLeft().getX() + this.length, rect.getUpperLeft().getY(),
               rect.getUpperLeft().getX() + 0.1 + 2 * this.length, rect.getUpperLeft().getY());
       Line line3 = new Line(rect.getUpperLeft().getX() + 2 * this.length, rect.getUpperLeft().getY(),
               rect.getUpperLeft().getX() + 0.1 + 3 * this.length, rect.getUpperLeft().getY());
       Line line4 = new Line(rect.getUpperLeft().getX() + 3 * this.length, rect.getUpperLeft().getY(),
               rect.getUpperLeft().getX() + 0.1 + 4 * this.length, rect.getUpperLeft().getY());
       Line line5 = new Line(rect.getUpperLeft().getX() + 4 * this.length, rect.getUpperLeft().getY(),
               rect.getUpperLeft().getX() + 0.1 + 5 * this.length, rect.getUpperLeft().getY());
       Velocity newVelocity = currentVelocity;
       if (rect.getLeft().inLine(collisionPoint) || rect.getRight().inLine(collisionPoint)) {
           newVelocity = new Velocity(-currentVelocity.getX(), currentVelocity.getY());
       } else {
           if (line3.inLine(collisionPoint)) {
               speed = currentVelocity.getSpeed();
               newVelocity = Velocity.fromAngleAndSpeed(0, speed);
           }
           if (line1.inLine(collisionPoint)) {
               angle = currentVelocity.getAngle() - 60;
               speed = currentVelocity.getSpeed();
               newVelocity = Velocity.fromAngleAndSpeed(angle, speed);
           }
           if (line2.inLine(collisionPoint)) {
               angle = currentVelocity.getAngle() - 30;
               speed = currentVelocity.getSpeed();
               newVelocity = Velocity.fromAngleAndSpeed(angle, speed);
           }
           if (line4.inLine(collisionPoint)) {
               angle = currentVelocity.getAngle() + 30;
               speed = currentVelocity.getSpeed();
               newVelocity = Velocity.fromAngleAndSpeed(angle, speed);
           }
           if (line5.inLine(collisionPoint)) {
               angle = currentVelocity.getAngle() + 60;
               speed = currentVelocity.getSpeed();
               newVelocity = Velocity.fromAngleAndSpeed(angle, speed);
           }
       }
       return newVelocity;
   }
   // Add this paddle to the game.
   /**
    *
    * @param g a Game
    */
   public void addToGame(GameLevel g) {
       g.addSprite(this);
       g.addCollidable(this);
   }
   /**
   *
   * @param g a Game
   */
  public void removeFromGame(GameLevel g) {
      g.removeSprite(this);
      g.removeCollidable(this);
  }
}

