package sprites;

import biuoop.DrawSurface;
/**
 *
 * @author gal.
 *
 */
public class Backgruond4 implements Sprite {

    @Override
    public void drawOn(DrawSurface d) {
        int i, j;
        d.setColor(java.awt.Color.CYAN.darker());
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(java.awt.Color.white);
        for (j = 0; j < 10; j++) {
            for (i = 0; i < 20; i++) {
                d.drawLine(100 - i * 2 + j * 10, 440 + i * 12, 100 - i * 2 + j * 10, 450 + i * 12);
                d.drawLine(600 - i * 2 + j * 10, 510 + i * 12, 600 - i * 2 + j * 10, 520 + i * 12);
            }
        }
        for (i = 0; i < 2; i++) {
            d.setColor(java.awt.Color.gray.brighter());
            d.fillCircle(120 + i * 500, 445 + i * 50, 30);
            d.fillCircle(115 + i * 500, 410 + i * 50, 20);
            d.setColor(java.awt.Color.gray);
            d.fillCircle(145 + i * 500, 420 + i * 50, 30);
            d.setColor(java.awt.Color.DARK_GRAY.brighter());
            d.fillCircle(180 + i * 500, 430 + i * 50, 30);
            d.fillCircle(160 + i * 500, 450 + i * 50, 20);
        }
    }

    @Override
    public void timePassed() { }

}
