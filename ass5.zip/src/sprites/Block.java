package sprites;

import java.util.ArrayList;
import java.util.List;

import biuoop.DrawSurface;
import collision.Collidable;
import game.GameLevel;
import listeners.HitListener;
import listeners.HitNotifier;
import shapes.Point;
import shapes.Rectangle;

/**
 *
 * @author gal.
 *
 */
public class Block  implements Collidable, Sprite, HitNotifier {
    private Rectangle rect;
    private String hit1;
    private List<HitListener> hitListeners;
    /**
     *
     * @param rect a Rectangle
     */
    public Block(Rectangle rect) {
        this.rect = rect;
        this.hit1 = "X";
        this.hitListeners = new ArrayList<HitListener>();
    }
    /**
     *
     */
    public void timePassed() {
    }
    /**
     * @return a Rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }
    /**
     * @param surface a DrawSurface
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.getCollisionRectangle().getColor());
        surface.fillRectangle((int) this.rect.getUpperLeft().getX(), (int) this.rect.getUpperLeft().getY(),
                (int) this.rect.getWidth(), (int) this.rect.getHeight());
        surface.setColor(java.awt.Color.BLACK);
        surface.drawRectangle((int) this.rect.getUpperLeft().getX(), (int) this.rect.getUpperLeft().getY(),
                (int) this.rect.getWidth(), (int) this.rect.getHeight());
       // surface.drawText((int) (this.rect.getUpperLeft().getX() + this.getCollisionRectangle().getWidth() / 2),
               // (int) (this.rect.getUpperLeft().getY() + this.getCollisionRectangle().getHeight() / 2),
               // hit1,  25);

    }
    /**
     *
     * @param g a Game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }
    /**
     *
     * @param gameLevel a Game
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeSprite(this);
        gameLevel.removeCollidable(this);
    }
    /**
     *
     * @param x a int
     */
    public void setHit(int x) {
        this.hit1 = Integer.toString(x);
    }
    /**
     *
     */
    public void setHitS() {
        this.hit1 = "X";
    }
    /**
     *
     * @return the hit1
     */
    public String getHit() {
       return this.hit1;
    }
    /**
    *
    * @param hitter a Ball
    * @param collisionPoint a Point
    * @param currentVelocity a Velocity
    * @return a new velocity after the hit
    */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        this.notifyHit(hitter);
        if (this.hit1 != "X") {
            if ((Integer.parseInt(this.hit1)) > 1) {
                setHit(Integer.parseInt(this.hit1) - 1);
            } else {
                setHitS();
            }
        }
        Velocity newVelocity = null;
        if (this.rect.getDown().inLine(collisionPoint) || this.rect.getUp().inLine(collisionPoint)) {
            newVelocity = new Velocity(currentVelocity.getX(), -currentVelocity.getY());
        }
        if (this.rect.getRight().inLine(collisionPoint) || this.rect.getLeft().inLine(collisionPoint)) {
            newVelocity = new Velocity(-currentVelocity.getX(), currentVelocity.getY());
        }
        return newVelocity;
    }
    /**
    *
    * @param hl a listener to hit events.
    */
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }
   /**
   *
   * @param hl a listener to hit events.
   */
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }
    /**
     *
     * @param hitter a Ball
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
           hl.hitEvent(this, hitter);
        }
     }
}

