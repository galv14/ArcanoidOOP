package sprites;

import biuoop.DrawSurface;
import game.Counter;
import game.GameLevel;
/**
 *
 * @author gal.
 *
 */
public class ScoreIndicator implements Sprite {
    private Counter score;
    /**
     *
     * @param scoreCounter a Counter
     */
    public ScoreIndicator(Counter scoreCounter) {
        this.score = scoreCounter;
    }

    @Override
    public void drawOn(DrawSurface d) {
        d.drawText(400, 22, "score: " + Integer.toString(score.getValue()), 25);
       // d.fillRectangle(500,60,100,200);
    }

    @Override
    public void timePassed() {
    }
    /**
    *
    * @param g a Game
    */
   public void addToGame(GameLevel g) {
       g.addSprite(this);
   }

}
